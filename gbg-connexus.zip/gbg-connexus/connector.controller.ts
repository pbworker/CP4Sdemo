/*
IBM Confidential

OCO Source Materials

5747-SM3

© Copyright IBM Corp. 1992, 1993

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.
*/


import {
  BaseSchema, connector, service, condition, seeds,
  Aliases, AliasedConnector, Result, Seeds, LogicalType, PossibleValue, Entity, SeedKey, LOGGER, Status

} from 'connector-sdk';
import * as config from './connector.conf.json';
import { aliases, schema } from './connector.aliases';
import { loggers } from 'winston';

const soapRequest = require('easy-soap-request');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const convert = require('xml-js');

const url = 'https://idmp.gb.co.uk:443/idm-globalservices-ws/services/v19a';
const header = {
  'Content-Type': 'text/xml;charset=UTF-8'
};

const tokens: any[] = [];

const SearchProfile =	"421DBE00-BEE7-4D88-A32F-38562923A7DF";
const PersonDetailsProfile	=	"D3C97B64-0AF6-420C-AC83-F29F0118B310";
const BusinessDetailsProfile	=	"ACE11E80-651D-4744-B13C-95D3E5F865B9";
const PropertyDetailsProfile	=	"7920F5DB-A7E7-4378-9830-62446E5CBA97";
const PremiumServicesProfile	=	"E69E1F3A-11C6-4DCC-96C0-6BE8180144D5";	  

function loadXmlTemplate(filename: string): string {
  const filenameWithPath = path.join(__dirname, 'request-templates', filename);
  return fs.readFileSync(filenameWithPath, 'utf-8');
}

function tenMinutesInTheFuture(): Date {
  return new Date(new Date().getTime() + 10 * 60000); 
}

function setPlaceholder(xml: string, name: string, value: string) {
  return xml.replace("${" + name + "}", value || "?");
}

function getSOAPBodyAsJS(xml: string) {
  const asJson = JSON.parse(convert.xml2json(xml, {compact: true, spaces: 4}));
  return asJson["SOAP-ENV:Envelope"]["SOAP-ENV:Body"];
}

function getResponseArray(xml: string) {

  let section = getSOAPBodyAsJS(xml);
  if (section["mes:ExecuteTraceResponse"]) {
    section = section["mes:ExecuteTraceResponse"];
  }

  section = section["mes:profileResponse"];
  
  section = asArray(section["req:profileResponseDetails"]);

  for (const profileResponseDetails of section) {
    delete profileResponseDetails["req:invoice"];
  }
  const result: any[] = []

  for (const profileResponseDetails of section) {
    const traceResponse = profileResponseDetails["req:traceResponse"];
    const responseArray = asArray(traceResponse["req:response"]);
    for (const response of responseArray) {
      result.push(response);
    }
  }
  
  //console.log("got req:traceResponse array of size " + result.length); 

  return result;
}

function asArray(value: any): any[]{
  if (!value) {
    return [];
  }

  if (Array.isArray(value)) {
    return value;
  }
  
  return [value];
}

function getText(obj: any, propertyName: string) {
  if (obj[propertyName]) {
    return obj[propertyName]._text;
  }
  return undefined;
}

function getFloat(obj: any, propertyName: string) {
  if (obj[propertyName]) {
    const parsed = parseFloat(obj[propertyName]._text.trim());
    return parsed === NaN ? undefined : parsed;
  }
  return undefined;
}

function getMpan(address: any) {
  /*
<trace:utilitiesInformation>
  
                           <data:electricityInformation>
                              <data:meterPoint>
                                 <data:mpan>1300053160066</data:mpan>
  */
  const mpan = address["trace:utilitiesInformation"]?.["data:electricityInformation"]?.["data:meterPoint"]?.["data:mpan"]?._text;
  return mpan;
}

function parseAddress(result: Result, address: any, expandForPremiumList: string[], linkedEntity?: Entity) {
  
  const buildingNumber = getText(address, "trace:buildingNumber");
  const buildingName = getText(address, "trace.buildingName");
  const street = getText(address, "trace:street");
  const town = getText(address, "trace:town");
  const district = getText(address, "trace.district");
  const postCode = getText(address, "trace:postCode");
  const mpan = getMpan(address);

  let entity: Entity | undefined;
  // don't add array entities if no detail
  if (buildingNumber || buildingName || street || town || postCode) {
    let id: string;
    if (mpan) {
      id = `mpan:${mpan}`;
    } else 
    {
      id = `full:${buildingNumber}:${buildingName}:${street}:${town}:${district}:${postCode}`;
    }

    entity = result.addEntity(id, schema.Address);
    entity.setProperty(schema.Address.House, buildingNumber);
    entity.setProperty(schema.Address.Street, street);
    entity.setProperty(schema.Address.City, town);
    entity.setProperty(schema.Address.Zipcode, postCode);
    // this is the label
    entity.setProperty(schema.Address.Display, getLabel([buildingNumber, street, town, postCode]) )

    const geo = address["trace:geographicInformation"];
    if (geo && getFloat(geo, "data:latitude") && getFloat(geo, "data:longitude")) {
      entity.setProperty(schema.Address.Geo, {
        type: "Point",
        coordinates: [getFloat(geo, "data:longitude"), getFloat(geo, "data:latitude")]
      });
    }

    if (linkedEntity) {
      const link = result.addLink(`${entity.id}_${linkedEntity.id}`, schema.Associated, entity, linkedEntity);
    }
  }

  const personArray = asArray(address["trace:persons"]?.["trace:person"]);

  for (const person of personArray) {
    parsePerson(result, person, entity);
    expandForPremiumList.push(getText(person, "trace:personRecordId"));
  }
  
}

function getLabel(array: string[]): string {
  return array.filter(x => x).join(" ");
}

function getDate(dateStructure: any) {
  const value = dateStructure["trace:value"];
  if (value) {
    const dayValue = value["data:day"]?._text;
    const day = dayValue ? ("0" + dayValue).slice(-2) : dayValue; // pad with zero if single digit
    const monthValue = ("0" + value["data:month"]?._text).slice(-2);
    const month = monthValue ? ("0" + monthValue).slice(-2) : monthValue; // pad with zero if single digit
    const year = value["data:year"]?._text; // do we ever see 2 digit dates?

    if (day && month && year) {
      return `${year}-${month}-${day}`;
    }
  }
  return undefined;
}

function parsePerson(result: Result, person: any, linkedEntity?: Entity) {


  const entity = result.addEntity(getText(person, "trace:personRecordId"), schema.Person);
  const firstName = getText(person, "trace:firstName");
  const middleName = getText(person, "trace:middleName");
  const surname = getText(person, "trace:lastName");

  entity.setProperty(schema.Person.Forenames, firstName);
  entity.setProperty(schema.Person.Surname, surname);
  
  // DOB
  const datesOfBirth = person["trace:datesOfBirth"];
  if (datesOfBirth) {
    const dateOfBirth = asArray(datesOfBirth["trace:dateOfBirth"]);
    if(dateOfBirth[0]) { // only take the first one
      entity.setProperty(schema.Person.DateOfBirth, getDate(dateOfBirth[0]));
    }
  } 

  // the label
  entity.setProperty(schema.Person.Display, getLabel([firstName, middleName, surname]));

  if (linkedEntity) {
    const link = result.addLink(`${entity.id}_${linkedEntity.id}`, schema.Associated, entity, linkedEntity);
  }


  parseMobiles(result, person, entity);
  parseLandlines(result, person, entity);
  parseEmails(result, person, entity);
}

function parseLandlines(result: Result, person: any, linkedEntity: Entity) {

 const landlines = asArray(person["trace:consentedlandlines"]?.["trace:sourcedValue"]);
 
 for (const landline of landlines) {
   const number: string = landline["trace:value"]?._text;
   const entity = result.addEntity(number, schema.Phone);
   entity.setProperty(schema.Phone.Number, number);
   entity.setProperty(schema.Phone.DisplayInternational, number);
   entity.setProperty(schema.Phone.Type, "Landline");

   const link = result.addLink(`${number}_${linkedEntity.id}`, schema.Associated, entity, linkedEntity);
 }
}

function parseMobiles(result: Result, person: any, linkedEntity: Entity) {
  /*
  <trace:person>
  <trace:personRecordId>63011985</trace:personRecordId>
  <trace:gasrGoneAwayInfo/>
  <trace:consentedMobiles>
     <trace:sourcedValue>
        <trace:value>07970619792</trace:value>
        <trace:lastUpdated>
           <data:day>25</data:day>
           <data:month>10</data:month>
           <data:year>2020</data:year>
        </trace:lastUpdated>
        <trace:confidence>2</trace:confidence>
     </trace:sourcedValue>
  </trace:consentedMobiles>

  */

  const mobiles = asArray(person["trace:consentedMobiles"]?.["trace:sourcedValue"]);
  for (const mobile of mobiles) {
    const number: string = mobile["trace:value"]?._text;
    const entity = result.addEntity(number, schema.Phone);
    entity.setProperty(schema.Phone.Number, number);
    entity.setProperty(schema.Phone.DisplayInternational, number);
    entity.setProperty(schema.Phone.Type, "Mobile");

    const link = result.addLink(`${number}_${linkedEntity.id}`, schema.Associated, entity, linkedEntity);

  }
  

}

function parseEmails(result: Result, person: any, linkedEntity: Entity) {
/*
  <trace:consentedEmails>
     <trace:sourcedValue>
        <trace:value>philjmor@hotmail.com</trace:value>
     </trace:sourcedValue>
  </trace:consentedEmails>
*/
const emails = asArray(person["trace:consentedEmails"]?.["trace:sourcedValue"]);
 
for (const email of emails) {
  const address: string = email["trace:value"]?._text;
  const entity = result.addEntity(address, schema.Email);
  entity.setProperty(schema.Email.EmailAddress, address);

  const link = result.addLink(`${address}_${linkedEntity.id}`, schema.Associated, entity, linkedEntity);
}

}

async function makeRequest(token: any, template: string, params: any) {
    let xmlRequest = loadXmlTemplate(template);
    xmlRequest = setPlaceholder(xmlRequest, "token", token.token);
    xmlRequest = setPlaceholder(xmlRequest, "username", config.username);

    for (const paramName of Object.keys(params)) {
      xmlRequest = setPlaceholder(xmlRequest, paramName, params[paramName]);
    }

    // //console.log(xmlRequest);
    // //console.log("got xml " + xmlRequest);
    const { response: soapResponse } = await soapRequest({ url: url, headers: header, xml: xmlRequest, timeout: 10000 }); // Optional timeout parameter(milliseconds)
    //console.log("got response ");
    const { body, statusCode } = soapResponse;
    //console.log(statusCode);
    const asJson = JSON.parse(convert.xml2json(body, {compact: true, spaces: 4}));
    // //console.log(asJson);
    // //console.log(JSON.stringify(getSOAPBodyAsJS(body)["mes:ExecuteTraceResponse"]));
    const responseArray: any[] = getResponseArray(body);
    //console.log("got response array of size " + responseArray.length);
    return responseArray;
}

function parseResponses(result: Result, responses: any[]) {
  const expandForPremiumList: string[] = [];
  for (const response of responses) {
    const addresses = asArray(response["req:address"]);
    for (const address of addresses) {
      parseAddress(result, address, expandForPremiumList);
    }
  }
  return expandForPremiumList;
}

function getQueryTerm(term: string) {
  return !term || term === "undefined" ? "?" : term; 
}

async function doPhoneSearch(token: any, result: Result, phoneNumber: string) {
  let responses = await makeRequest(token, "PhoneLookup.xml", {phoneNumber});
  const expandForPremiumList = parseResponses(result, responses);
  await doPremiumLookup(token, result, expandForPremiumList);
}

async function doEmailSearch(token: any, result: Result, email: string) {
  let responses = await makeRequest(token, "EmailLookup.xml", {email});
  const expandForPremiumList = parseResponses(result, responses);
  await doPremiumLookup(token, result, expandForPremiumList);
}

async function doPremiumLookup(token: any, result: Result, ids: string[]) {
  for (const pickId of ids) { 
    const responses = await makeRequest(token, "PremiumLookup.xml", {pickId, profile: PremiumServicesProfile});
    parseResponses(result, responses);
  }
}

/**
 * Sample Connector
 */
@connector({
  name: "GBG Connexus",
  description: "Provides searching against the GBG Connexus data"
})
export class GBGConnexus implements AliasedConnector {

  // required to be called at the end of each service request
  recycleToken(token: any) {
    if (token) {
      LOGGER.debug("Recycling token");
      tokens.push(token);
    }
  }

  // required by called at start of each service request
  async getToken() {

    let token = tokens.pop();
    
    if (!token || token.expires > tenMinutesInTheFuture()) {
      LOGGER.debug("Getting new token");
      token = await this.getNewToken();
    } else {
      LOGGER.debug("Using existing token");
    }
  
    return token;
  }

  // never called by users
  async getNewToken() {
    try {
      let xmlRequest = loadXmlTemplate('AuthenticateUser.xml');
      
      xmlRequest = setPlaceholder(xmlRequest, "username", config.username);
      xmlRequest = setPlaceholder(xmlRequest, "password", config.password);

      const { response } = await soapRequest({ url: url, headers: header, xml: xmlRequest, timeout: 10000 }); // Optional timeout parameter(milliseconds)
      const { body, statusCode } = response;

      const userResponse = getSOAPBodyAsJS(body)["mes:AuthenticateUserResponse"]
      const token = userResponse["mes:authenticationToken"]["_text"];
      const expires = new Date(Date.parse(userResponse["mes:authenticationTime"]["_text"]));
      
      return {token, expires};
    } 
    catch(e) {
      LOGGER.error("Failed to get new Token due to " + e);
    }
  }

  // Boiler-plate as implements AliasedConnector
  getAliases() {
    return new Aliases(aliases);
  }

  // Boiler-plate as implements AliasedConnector
  getSchema(): BaseSchema {
    return schema;
  }

  // Boiler-plate to return connector deployment folder
  getDir() {
    return __dirname;
  }

  @service({name: "Expand or Search", description: "Expands if the id is still valid, otherwise searches"})
  async expand(@seeds(
    {
      // types: [schema.Person, schema.Address, schema.Phone, schema.Email],
      min: 1,
      max: 10
    }
  ) seeds: Seeds) {
    //console.log("expand called");
    const result = new Result();
    const token = await this.getToken();
    try {
      for(const seed of seeds.entities) {
        //console.log("looping seeds");
        for (const connectorKey of seed.connectorKeysByType(schema.Person)) {
          //console.log("looping person ids of seed");
          let responses;
          
          responses = await makeRequest(token, "DetailsLookup.xml", {pickId: connectorKey.id, profile: PersonDetailsProfile});
          parseResponses(result, responses);
          responses = await makeRequest(token, "PremiumLookup.xml", {pickId: connectorKey.id, profile: PremiumServicesProfile});
          parseResponses(result, responses);
        }
        for (const connectorKey of seed.connectorKeysByType(schema.Address)) {
          let responses;
          if (connectorKey.id.startsWith("mpan:")) {
            
            responses = await makeRequest(token, "MpanLookup.xml", {mpan: connectorKey.id.split(":")[1], profile: PropertyDetailsProfile});
            
          } else {
            const tokens = connectorKey.id.split(":");
            const buildingNumber = getQueryTerm(tokens[1]);
            const buildingName = getQueryTerm(tokens[2]);
            const street = getQueryTerm(tokens[3]);
            const town = getQueryTerm(tokens[4]);
            const district = getQueryTerm(tokens[5]);
            const postCode = getQueryTerm(tokens[6]);

            const terms = {buildingNumber, buildingName, street, town, district, postCode, profile: PropertyDetailsProfile };
            responses = await makeRequest(token, "AddressLookup.xml", terms);
  
          }
          parseResponses(result, responses);
        }
        for (const connectorKey of seed.connectorKeysByType(schema.Email)) {
          if (seed.hasProperty(schema.Email.EmailAddress))
          await doEmailSearch(token, result, seed.getProperty(schema.Email.EmailAddress));
        }
        for (const connectorKey of seed.connectorKeysByType(schema.Phone)) {
          if (seed.hasProperty(schema.Phone.Number))
          await doPhoneSearch(token, result, seed.getProperty(schema.Phone.Number));
        }
      }
    }
    finally {
      this.recycleToken(token);
    }
    return result;
  }
 /*
  * Person Search
  */
 @service({ name: "Person Search", 
  description: "Search for people. Narrow search by entering location terms.",   
  async: true })
 async personSearch(
   
  @condition({
     label: "First Name",
     description: "Enter the first name",
     logicalType: LogicalType.SINGLE_LINE_STRING,
     mandatory: true,
   }) firstName: string,

  @condition({
    label: "Surname",
    description: "Enter the surname",
    logicalType: LogicalType.SINGLE_LINE_STRING,
    mandatory: true,
  }) lastName: string,
  @condition({
    label: "Date of Birth",
    description: "Enter the date of birth",
    logicalType: LogicalType.SINGLE_LINE_STRING,
  }) dateOfBirth: string,
@condition({
    label: "Town",
    description: "Enter the town",
    logicalType: LogicalType.SINGLE_LINE_STRING,
  }) town: string,
  @condition({
    label: "Postcode",
    description: "Enter the postcode",
    logicalType: LogicalType.SINGLE_LINE_STRING,
  }) postCode: string
  ) {
    const result = new Result();
    const token = await this.getToken();
    try {
      let responses = undefined;
      if (town || postCode) {
        responses = await makeRequest(token, "PersonLocationLookup.xml", {firstName, lastName, dateOfBirth, town, postCode});
      } else {
        responses = await makeRequest(token, "PersonLookup.xml", {firstName, lastName, dateOfBirth});
      }
      if (responses) {
        const expandForPremiumList = parseResponses(result, responses);
        await doPremiumLookup(token, result, expandForPremiumList);
      }
    }
    catch (ex) {
      LOGGER.error("problem running search -  " + ex.message);
    } finally {
      this.recycleToken(token);
    }
    
    return result;
  }


  /*
  * Building Search
  */
  @service({ name: "Building Search", description: "Search GBG Connexus." })
  async building(
    
    @condition({
      label: "Building Number",
      description: "Enter the building number",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    buildingNumber: string,
    @condition({
      label: "Building Name",
      description: "Enter the building name",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    buildingName: string,
    @condition({
      label: "Street",
      description: "Enter the street",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    street: string,
    @condition({
      label: "District",
      description: "Enter a district",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    district: string,

    @condition({
      label: "Town",
      description: "Enter a town",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    town: string,

    @condition({
      label: "Postcode",
      description: "Enter the postcode",
      logicalType: LogicalType.SINGLE_LINE_STRING,
    })
    postcode: string,

  ) {
    const result = new Result();
    const token = await this.getToken();
    try {
      const responses = await makeRequest(token, "AddressLookup.xml", {buildingNumber, buildingName, street, district, town, postCode: postcode });
      parseResponses(result, responses);
    }
    catch (ex) {
      LOGGER.error("problem running search -  " + ex.message);
    } finally {
      this.recycleToken(token);
    }
    
    return result;
  }


  
 /*
  * Phone Search
  * Works with 07970619792
  */
 @service({ name: "Phone Search", description: "Search GBG Connexus." })
 async phoneSearch(
   
  @condition({
     label: "Phone Number",
     description: "Enter the phone number",
     logicalType: LogicalType.SINGLE_LINE_STRING,
     mandatory: true
   }) phoneNumber: string
 ){
  const result = new Result();
  const token = await this.getToken();
  try {
    await doPhoneSearch(token, result, phoneNumber);
  }
  catch (ex) {
    LOGGER.error("problem running search -  " + ex.message);
  } finally {
    this.recycleToken(token);
  }
  
  return result;
 }


 /*
  * Email Search
  * Works with philjmor@hotmail.com
  */
 @service({ name: "Email Search", description: "Search GBG Connexus." })
 async emailSearch(
   
  @condition({
     label: "Email",
     description: "Enter the email address",
     logicalType: LogicalType.SINGLE_LINE_STRING,
     mandatory: true
   }) email: string
 ){
  const result = new Result();
  const token = await this.getToken();
  try {

    await doEmailSearch(token, result, email);
  }
  catch (ex) {
    LOGGER.error("problem running search -  " + ex.message);
  } finally {
    this.recycleToken(token);
  }
  
  return result;
 } 

 

    

}

