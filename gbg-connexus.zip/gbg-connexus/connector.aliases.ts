import { aliasProxyHandler, Aliases, BaseSchema, EntityType, LinkType } from 'connector-sdk';


// Entity Interfaces:
interface Company extends EntityType {
  Name: string,
  CompanyNumber: string,
  Display: string,
}

interface Email extends EntityType {
  EmailAddress: string;
}

interface Phone extends EntityType {
  Type: string;
  Number: string;
  DisplayInternational: string;
}

interface Person extends EntityType {
  FullName: string,
  Forenames: string,
  Surname: string,
  DateOfBirth: string,
  Display: string,
}

interface Address extends EntityType {
  House: string;
  Street: string;
  City: string;
  State: string;
  Country: string;
  Zipcode: string;
  Geo: string;
  Display: string,
}

interface Associated extends LinkType {
  From: string;
  To: string;
  Type: string;
}

// Pull entity and link type interfaces together into the Schema interface
interface Schema extends BaseSchema {
  // Aliases
  Company: Company;
  Person: Person;
  Address: Address;
  Phone: Phone;
  Email: Email;
  Associated: Associated;

}


const gbg: Schema = {
  
  Files: {
    SchemaFile: "pipl-schema.xml",
    ChartingSchemesFile: "pipl-schema-ChartingSchemes.xml",
  },
  
  SchemaShortName: "gbg",

  DefaultEntity: {
    typeId: "ET1"
  },
  DefaultLink: {
    typeId: "LT1"
  },
  Person: {
    typeId: "ET1",
    FullName: "PT2",
    DateOfBirth: "PT6",
    Forenames: "PT3",
    Surname: "PT4",
    Display: "PT66"
  },
  Company: {
    typeId: "ET4",
    Name: "ORG2", 
    CompanyNumber: "ORG11",
    Display: "XX"
  },

  Email: {
    typeId: "ET2",
    EmailAddress: "PT12"
  },

  Phone: {
    typeId: "ET4",
    Type: "PT67",
    DisplayInternational: "PT23",
    Number: "PT21"
  },

  Address: {
    typeId: "ET9",
    House: "PT55",
    Street: "PT54",
    City: "PT53",
    State: "PT52",
    Country: "PT51",
    Zipcode: "PT56",
    Geo: "PT100",
    Display: "PT57"
  },


  Associated: {
    typeId: "LT1",
    From: "PT60",
    To: "PT61",
    Type: "PT59"
  },
}

const intel: Schema = {


  DefaultEntity: {
    typeId: "ET1"
  },
  DefaultLink: {
    typeId: "LT1"
  },
  Person: {
    typeId: "ET1",
    FullName: "PT2",
    DateOfBirth: "PT6",
    Forenames: "PT3",
    Surname: "PT4",
    Display: "PT66"
  },
  Company: {
    typeId: "ET4",
    Name: "ORG2", 
    CompanyNumber: "ORG11",
    Display: "XX"
  },

  Email: {
    typeId: "ET2",
    EmailAddress: "PT12"
  },

  Phone: {
    typeId: "ET4",
    Type: "PT67",
    DisplayInternational: "PT23",
    Number: "PT21"
  },

  Address: {
    typeId: "ET9",
    House: "PT55",
    Street: "PT54",
    City: "PT53",
    State: "PT52",
    Country: "PT51",
    Zipcode: "PT56",
    Geo: "PT100",
    Display: "PT57"
  },


  Associated: {
    typeId: "LT1",
    From: "PT60",
    To: "PT61",
    Type: "PT59"
  },
}

// Create a new Proxy for the Schema
export const schema: Schema = new Proxy(<Schema>{}, aliasProxyHandler);

export const aliases: any = { gbg, intel };


