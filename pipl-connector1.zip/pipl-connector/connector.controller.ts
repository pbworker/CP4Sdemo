import {
  connector,
  service,
  condition,
  Aliases,
  AliasedConnector,
  Result,
  Seeds,
  seeds,
  BaseSchema,
  Entity,
  LogicalType
} from "connector-sdk";
import * as config from "./connector.conf.json";
import { aliases, schema } from "./connector.aliases";
import { LogErrorProvider } from "@loopback/rest";
import { v4 as uuidv4 } from "uuid";
import { print } from "util";

const axios = require("axios");
const qs = require("qs");
var fs = require("fs");
const isDebugMode = true;

// Some utility functions
function getBoolean(value: any) {
  switch (value) {
    case true:
    case "true":
    case 1:
    case "1":
    case "on":
    case "yes":
      return true;
    default:
      return false;
  }
}

function logDebug(msg: string) {
  if (isDebugMode) {
    console.log(msg);
  }
}

function addAdditionalNameEntity(
  result: Result,
  datum: any,
  primaryEntity?: Entity
) {
  let entity = result.addEntity(datum.display, schema.Alias);
  entity.setProperty(schema.Alias.prefix, datum.prefix);
  entity.setProperty(schema.Alias.first_name, datum.first);
  entity.setProperty(schema.Alias.middle_name, datum.middle);
  entity.setProperty(schema.Alias.last_name, datum.last);
  entity.setProperty(schema.Alias.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Alias.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Person.Display, datum.display);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.AlternativeName,
      primaryEntity,
      entity
    );
  }
}

function addEmailEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.address_md5, schema.Email);
  entity.setProperty(schema.Email.address, datum.address);
  entity.setProperty(
    schema.Email.email_provider,
    datum["@email_provider"].toString()
  );
  entity.setProperty(schema.Email.type, datum["@type"]);
  entity.setProperty(schema.Email.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Email.valid_since, datum["@valid_since"]);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.EmailLink,
      primaryEntity,
      entity
    );
  }
}

function addUsernameEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.content, schema.Username);
  entity.setProperty(schema.Username.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Username.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Username.content, datum.content);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.AlternativeName,
      primaryEntity,
      entity
    );
  }
}

function addUserIDEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.content, schema.Username);
  entity.setProperty(schema.Username.content, datum.content);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.AlternativeName,
      primaryEntity,
      entity
    );
  }
}

function addUrlEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(
    datum.url,
    schema.Url
  );
  if (datum["@sponsored"])
    entity.setProperty(schema.Url.sponsored, datum["@sponsored"]);
  entity.setProperty(schema.Url.category, datum["@category"]);
  entity.setProperty(schema.Url.domain, datum["@domain"]);  
  //@TODO - add the name
  //if (datum["@name"])
  //  entity.setProperty(schema.Url.name, datum["@name"]);
  entity.setProperty(schema.Url.url, datum.url);

  let source_id = "";
  if (datum["@source_id"])
    source_id = datum["@source_id"];
  else
    source_id = uuidv4();

  let name = "";
  if (datum["@name"])
    name = datum["@name"];
  else
    name = "URL";
  entity.setSourceReference(source_id,name,datum["@domain"],datum.url,undefined,datum["@category"]);

  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.Associated,
      primaryEntity,
      entity
    );
  }
}

function addAddressEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.display, schema.Address);
  entity.setProperty(schema.Address.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Address.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Address.house, datum.house);
  entity.setProperty(schema.Address.street, datum.street);
  entity.setProperty(schema.Address.city, datum.city);
  entity.setProperty(schema.Address.state, datum.state);
  entity.setProperty(schema.Address.country, datum.country);
  entity.setProperty(schema.Address.zipcode, datum.zipcode);
  entity.setProperty(schema.Address.display, datum.display);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.AddressOf,
      primaryEntity,
      entity
    );
  }
}

function addPhoneEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.number, schema.Phone);
  entity.setProperty(schema.Phone.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Phone.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Phone.type, datum["@type"]);
  entity.setProperty(schema.Phone.country_code, datum.country_code.toString());
  entity.setProperty(schema.Phone.number, datum.number.toString());
  entity.setProperty(schema.Phone.display, datum.display);
  entity.setProperty(
    schema.Phone.display_international,
    datum.display_international
  );
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.AccessTo,
      primaryEntity,
      entity
    );
    link.setProperty(schema.AddressOf.Type, "Linked Phone");
  }
}

function addJobEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.title + datum.organization, schema.Job);
  entity.setProperty(schema.Job.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Job.last_seen, datum["@last_seen"]);
  entity.setProperty(schema.Job.title, datum.title);
  entity.setProperty(schema.Job.organisation, datum.organization);
  //entity.setProperty(schema.Job.date_start, datum.date_range.start);
  //entity.setProperty(schema.Job.date_end, datum.date_range.end);
  entity.setProperty(schema.Job.display, datum.display);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.CompanyRole,
      primaryEntity,
      entity
    );
    link.setProperty(schema.CompanyRole.Type, "Job: " + datum.title);
  }
}

function addEducationEntity(
  result: Result,
  datum: any,
  primaryEntity?: Entity
) {
  let entity = result.addEntity(
    datum.title + datum.organization,
    schema.Education
  );
  entity.setProperty(schema.Education.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Education.last_seen, datum["@last_seen"]);
  //entity.setProperty(schema.Education.date_start, datum.date_range.start);
  //entity.setProperty(schema.Education.date_end, datum.date_range.end);
  entity.setProperty(schema.Education.school, datum.school);
  entity.setProperty(schema.Education.degree, datum.degree);
  entity.setProperty(schema.Education.display, datum.display);
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.CompanyRole,
      primaryEntity,
      entity
    );
    link.setProperty(schema.CompanyRole.Type, "Education: " + datum.display);
  }
}

function addImageEntity(result: Result, datum: any, primaryEntity?: Entity) {
  let entity = result.addEntity(datum.thumbnail_token, schema.Images);
  entity.setProperty(schema.Images.valid_since, datum["@valid_since"]);
  entity.setProperty(schema.Images.url, datum.url);
  //Add the thumbnail token

  //@TODO: set this to use Pipl thumbnail service
  entity.setSourceReference(uuidv4(),"Image",undefined,datum.url,datum.url,"Image");  

  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.Associated,
      primaryEntity,
      entity
    );
  }
}

function addRelationshipEntity(
  result: Result,
  datum: any,
  primaryEntity?: Entity
) {
  let entity = result.addEntity(uuidv4(), schema.Relationship);
  //logDebug(datum);
  if (datum["@valid_since"])
    entity.setProperty(schema.Relationship.valid_since, datum["@valid_since"]);
  if (datum["@type"])
    entity.setProperty(schema.Relationship.type, datum["@type"]);
  if (datum["@subtype"])
    entity.setProperty(schema.Relationship.subtype, datum["@subtype"]);
  if (datum.names) {
    if (datum.names[0].first_name)
      entity.setProperty(schema.Relationship.first_name, datum.names[0].first_name);
    if (datum.names[0].middle_name)
      entity.setProperty(schema.Relationship.middle_name, datum.names[0].middle_name);
    if (datum.names[0].last_name)
      entity.setProperty(schema.Relationship.last_name, datum.names[0].last_name);
    if (datum.names[0].display)
      entity.setProperty(schema.Relationship.display, datum.names[0].display);
  }
  if (primaryEntity) {
    let link = result.addLink(
      primaryEntity.id + "_" + entity.id,
      schema.Associated,
      primaryEntity,
      entity
    );
  }
}

function processPersonData(data: any, result: Result, personEntity?: Entity) {
  logDebug("processPersonData - start");

  if (data.names) {
    data.names.forEach((datum: any, index: any) => {
      if (index > 0) {
        addAdditionalNameEntity(result, datum, personEntity);
      }
    });
  }

  //Add locations
  if (data.addresses) {
    data.addresses.forEach((datum: any, index: any) => {
      addAddressEntity(result, datum, personEntity);
    });
  }

  //Add contact information - phones and emails
  if (data.phones) {
    data.phones.forEach((datum: any, index: any) => {
      addPhoneEntity(result, datum, personEntity);
    });
  }
  if (data.emails) {
    data.emails.forEach((datum: any, index: any) => {
      addEmailEntity(result, datum, personEntity);
    });
  }

  //Add social data - images, relationships, user_ids, usernames and urls
  if (data.images) {
    data.images.forEach((datum: any, index: any) => {
      addImageEntity(result, datum, personEntity);
    });
  }
  if (data.relationships) {
    data.relationships.forEach((datum: any, index: any) => {
      addRelationshipEntity(result, datum, personEntity);
    });
  }
  if (data.usernames) {
    data.usernames.forEach((datum: any, index: any) => {
      addUsernameEntity(result, datum, personEntity);
    });
  }
  if (data.user_ids) {
    data.user_ids.forEach((datum: any, index: any) => {
      addUserIDEntity(result, datum, personEntity);
    });
  }
  if (data.urls) {
    data.urls.forEach((datum: any, index: any) => {
      addUrlEntity(result, datum, personEntity);
    });
  }

  //Add professional info - jobs and educations
  if (data.jobs) {
    data.jobs.forEach((datum: any, index: any) => {
      addJobEntity(result, datum, personEntity);
    });
  }
  if (data.educations) {
    data.educations.forEach((datum: any, index: any) => {
      addEducationEntity(result, datum, personEntity);
    });
  }

  logDebug("processPersonData - end");
}

function addVehicle(result: Result, source: any, personEntity?: Entity) {
  let vehicle_vin = "";
  let vehicle_make = "";
  let vehicle_model = "";
  let vehicle_type = "";
  let vehicle_last_seen = "";
  let vehicle_valid_since = "";

  const TAG_VEHICLE_VIN = "auto vin";
  const TAG_VEHICLE_MAKE = "auto make";
  const TAG_VEHICLE_MODEL = "auto model";
  const TAG_VEHICLE_TYPE = "auto type";

  if (source["tags"] != null) {
    source.tags.forEach((tag: any, index: any) => {
      switch (tag["@classification"]) {
        case TAG_VEHICLE_VIN:
          vehicle_vin = tag["content"];
          vehicle_valid_since = tag["@valid_since"];
          vehicle_last_seen = tag["@last_seen"];
          break;
        case TAG_VEHICLE_MAKE:
          vehicle_make = tag["content"];
          vehicle_valid_since = tag["@valid_since"];
          vehicle_last_seen = tag["@last_seen"];
          break;
        case TAG_VEHICLE_MODEL:
          vehicle_model = tag["content"];
          vehicle_valid_since = tag["@valid_since"];
          vehicle_last_seen = tag["@last_seen"];
          break;
        case TAG_VEHICLE_TYPE:
          vehicle_type = tag["content"];
          vehicle_valid_since = tag["@valid_since"];
          vehicle_last_seen = tag["@last_seen"];
          break;
        default:
          //statements;
          break;
      }
    });
  }

  logDebug(
    vehicle_vin +
      " " +
      vehicle_make +
      " " +
      vehicle_model +
      " " +
      vehicle_type +
      " " +
      vehicle_last_seen +
      " " +
      vehicle_valid_since
  );

  let vehicleEntity = result.addEntity(
    vehicle_vin == "" ? uuidv4() : vehicle_vin,
    schema.Vehicle
  );
  if (vehicle_make != undefined)
    vehicleEntity.setProperty(schema.Vehicle.make, vehicle_make);
  if (vehicle_model != undefined)
    vehicleEntity.setProperty(schema.Vehicle.model, vehicle_model);
  if (vehicle_vin != undefined)
    vehicleEntity.setProperty(schema.Vehicle.vin, vehicle_vin);
  if (vehicle_type != undefined)
    vehicleEntity.setProperty(schema.Vehicle.type, vehicle_type);
  if (vehicle_type != vehicle_last_seen)
    vehicleEntity.setProperty(schema.Vehicle.lastSeen, vehicle_last_seen);
  if (vehicle_type != vehicle_valid_since)
    vehicleEntity.setProperty(schema.Vehicle.validSince, vehicle_valid_since);

  if (personEntity) {
    let link = result.addLink(
      personEntity.id + "_" + vehicleEntity.id,
      schema.Associated,
      personEntity,
      vehicleEntity
    );
  }
}

function processPersonSourcesData(
  sources: any,
  result: Result,
  primaryEntity?: Entity
) {
  logDebug("Investigating source data");
  if (sources) {
    sources.forEach((source: any, index: any) => {
      if (source["@match"] == 1.0) {
        //Look for vehicle source information
        if (source["@name"].toLowerCase().includes("auto")) {
          logDebug(
            "Source name is: " + source["@name"] + " and @id is " + source["@id"]
          );
          if (source["tags"]) {
            logDebug("Has tags, adding vehicle information...");
            addVehicle(result, source, primaryEntity);
          }
        }
      }
    });
  }
}

function setPersonEntityInfo(
  entity: Entity,
  datum: any,
  sources: any,
  isPossiblePerson: boolean,
  result: Result
) {
  logDebug(
    "names: " +
      datum.names[0].first +
      " " +
      datum.names[0].last +
      " " +
      datum.names[0].display
  );
  entity.setProperty(schema.Person.UniqueRef, entity.id);
  entity.setProperty(schema.Person.Forenames, datum.names[0].first);
  entity.setProperty(schema.Person.Surname, datum.names[0].last);
  entity.setProperty(schema.Person.Display, datum.names[0].display);
  if (datum.gender) {
    entity.setProperty(schema.Person.Gender, datum.gender.content);
  }
  entity.setProperty(schema.Person.AdditionalInfo, datum["@search_pointer"]);

  //@TODO - store the JSON of the person

  if (!isPossiblePerson) {
    entity.setProperty(schema.Person.PossiblePerson, null);
    processPersonData(datum, result, entity);
    processPersonSourcesData(sources, result, entity);
  }
  else {
    entity.setProperty(schema.Person.PossiblePerson, true);
  }
}

/**
 * Connector
 */
@connector({
  name: "PIPL Connector"
})
class PIPLConnector implements AliasedConnector {
  result: Result;  
  constructor() {
    console.log("Creating a new result object");
    this.result = new Result();
  }

  getAliases() {
    return new Aliases(aliases);
  }

  getSchema(): BaseSchema {
    return schema;
  }

  // Boiler-plate to return connector deployment folder
  getDir() {
    return __dirname;
  }

  /*
   * find contacts by name
   */
  @service({ name: "Search Person" })

  /*
  defaultValue: "1", possibleValues:[
    { displayName: "True", value: "1" },
    { displayName: "False", value: "0" }] 
    @condition({ label: "Expand", logicalType: LogicalType.BOOLEAN) isExpand: boolean

    */
  async searchPerson(
    @condition({ label: "Email", logicalType: LogicalType.SINGLE_LINE_STRING })
    inputEmail: string,
    @condition({ label: "Phone", logicalType: LogicalType.SINGLE_LINE_STRING })
    inputPhone: string
  ) {

    //var result = new Result();
    try {
      // const call = axios.create({
      //   responseType: "json"
      // });

      var inputData: any = qs.stringify({
        email: inputEmail,
        phone: inputPhone,
        show_sources: "all",
        key: config.businessKey
      });

      logDebug("Input email is:" + inputEmail);
      logDebug("Input phone is:" + inputPhone);
      logDebug("inputData is:" + inputData);

      var seedEntity;
      var entityType;
      if (inputEmail.length > 0 && inputPhone == null) {
        logDebug("Expanding an email address: " + inputEmail);
        var emailEntity = this.result.addEntity(inputEmail, schema.Email);
        console.log("here")
        emailEntity.setProperty(schema.Email.address, inputEmail);
        //primaryEntity.setProperty(schema.Email.type,piplResponse.query.emails[0].type);
        console.log("here2")
        seedEntity = emailEntity;
        entityType = emailEntity.type;
      }
      if (inputPhone != null && inputPhone.length > 0 && inputEmail == null) {
        console.log("here_phone")
        logDebug("Expanding an phone: " + inputPhone);
        var phoneEntity = this.result.addEntity(inputPhone, schema.Phone);
        phoneEntity.setProperty(schema.Phone.number, inputPhone);        
        seedEntity = phoneEntity;
        entityType = phoneEntity.type;
      }
      //logDebug(JSON.stringify(response.data));

      //Check what searched by
      //Only by phone
      //Only by email
      //Only by username
      //If multiple conditions       
      await this.processPiplConnectorRequest(inputData,seedEntity,entityType).then((piplResponse: any) => {
        //return this.result;
      })
      .catch((error: any) => {
        this.result.status = "At least some results were not available";
        console.log("Caught error in Search Person service: " + error);
      });

      return this.result;
    } catch (err) {
      if (err && err.response) {
        console.log("Error in service searchPerson: " + err);
      }
      throw err;
    }
  }

  /*
   * Expand by Person, Email, Phone
   * @TODO others
   */
  @service({ name: "Expand" })
  async expand(
    @seeds({
      //types: [schema.Person, schema.Phone, schema.Email],
      min: 1,
      max: 1
    })
    seeds: Seeds
  ) {
    //var result = new Result();

    try {
      var inputData: any;       
      //console.log('seeds: ' + seeds.entities[0].rawSeed);
      for (let i=0; i<seeds.entities.length; i++) {      
        if (seeds.entities[i].type == schema.Person) { 
          console.log("Person seed");
          //console.log(seeds.entities[i].type);
          let search_pointer = seeds.entities[i].getProperty(schema.Person.AdditionalInfo);          

          //console.log("Person id is " + seeds.entities[i].getProperty(schema.Person.UniqueRef));
          //console.log("Person id in the person seed is:" + seedEntity.id);
          inputData = qs.stringify({
            search_pointer: search_pointer,
            key: config.businessKey
          });          
        }
        if (seeds.entities[i].type == schema.Phone) {
          logDebug("The seed is an Phone entity")
          let phoneNumber = seeds.entities[i].getProperty(schema.Phone.number);
          inputData = qs.stringify({
            phone: phoneNumber,
            key: config.businessKey
          });
        }
        if (seeds.entities[i].type == schema.Email) {
          logDebug("The seed is an Email entity")
          let emailAddress = seeds.entities[i].getProperty(schema.Email.address);
          if (emailAddress.match()) {
            //@TODO: check if the email does not meet a valid email requirements with  regex
          }          
          inputData = qs.stringify({
            email: emailAddress,
            key: config.businessKey
          });
        }

        //this.processPiplConnectorRequest(inputData,seeds.entities[i]); //this.result,
        let entity = this.result.addEntityFromSeed(seeds.entities[i]);
        console.log("Entity type=seed type?:" + (entity.type == seeds.entities[i].type));
        await this.processPiplConnectorRequest(inputData,entity,seeds.entities[i].type).then((piplResponse: any) => {
          //return this.result;
        })
        .catch((error: any) => {
          this.result.status = "At least some results were not available";
          console.log("Caught error in Search Person service: " + error);
        });        
      }

      // let primaryEntity = result.addEntityFromSeed(seeds.entities[0]);
      // console.log("0.2");

      

      // console.log("primaryEntity.id");

      // let entity_id = primaryEntity.id;
      // console.log("0.3");

      // const call = axios.create({
      //   responseType: "json"
      // });


      // var axios_config = {
      //   method: "post",
      //   url: "https://api.pipl.com/search/",
      //   headers: {
      //     "Content-Type": "application/x-www-form-urlencoded"
      //   },
      //   data: data
      // };

      // //console.log(JSON.stringify(response.data));

      // await axios(axios_config)
      //   .then((response: any) => {
      //     console.log("data: " + JSON.stringify(response.data));

      //     if (response.data.person) {
      //       primaryEntity.setProperty(schema.Person.PossiblePerson, false);
      //     } //  TODO:  Roy to deal with edge case of possible_persons

      //     processPersonData(response.data.person, result, primaryEntity);
      //   })
      //   .catch((error: any) => {
      //     result.status = "Warning";
      //     result.status = "At least some results were not available";
      //     console.log("Caught error: " + error);
      //   });

      //this.result.status = this.result.status || "OK";
      //this.result.statusMessage = this.result.statusMessage || `Found some results`; //`Found ${result.entityMap.size > 0} results`;
      return this.result;

    } catch (err) {
      if (err && err.response) {
        console.log(err);
      }
      throw err;
    }

    //return this.result;
  }
  
  //result:Result, async
  async processPiplConnectorRequest(inputData:any,seedEntity?:any,entityType?:any) {

    let isFoundResult = false;
    for (let i = 0; i < 3; i++) { 
      console.log("Search Person. Attempt #" + i)
      await this.runPiplAPIQuery(inputData)
        .then((piplResponse: any) => {
          console.log("Successfuly got Pipl response")
          //console.log("response: " + JSON.stringify(piplResponse));
          //console.log("data returned from response: " + JSON.stringify(response.data));

          // Process all data from real person result
          //console.log(piplResponse)

          if (piplResponse) {

            if (piplResponse.person) {
              isFoundResult = true;
              
              var isAddNewPersonEntity = true;
              var personEntity;

              if (seedEntity) {                
                console.log("There was a seed");
                console.log("Is Person type " + (seedEntity.type == schema.Person));
                if (entityType == schema.Person) {
                  console.log("There was a Person seed");                  
                  personEntity = seedEntity;
                  isAddNewPersonEntity = false;
                  //personId = seedEntity.id;
                  //personId = seedEntity.id; //getProperty(schema.Person.UniqueRef);
                  //console.log("personId is: " + personId);
                  //return;                  
                  //seedEntity.setProperty(schema.Person.PossiblePerson, false);                  
                }
              }

              if (isAddNewPersonEntity) {
                //Add a new Person entity
                let personId:string = uuidv4();
                personEntity = this.result.addEntity(personId, schema.Person);
              }
              
              console.log("Found a person, adding this to the result")
              console.log("Result is now: " + this.result)
              console.log("personEntity: " + personEntity)

              setPersonEntityInfo(
                personEntity,
                piplResponse.person,
                piplResponse.sources,
                false,
                this.result
              );

              if (seedEntity) {
                if (seedEntity.type == schema.Email) {
                  logDebug("Adding a link between the person and the email");
                  this.result.addLink(
                    seedEntity.getProperty(schema.Email.address) + "_" + personEntity.id,
                    schema.SubjectOf,
                    seedEntity,
                    personEntity
                  ); 
                }
                if (seedEntity.type == schema.Phone) {
                  logDebug("Adding a link between the person and the email");
                  this.result.addLink(
                    seedEntity.getProperty(schema.Phone.number) + "_" + personEntity.id,
                    schema.SubjectOf,
                    seedEntity,
                    personEntity
                  );
                }
              }

              //throw new Error("Debugging");

            } else if (piplResponse.possible_persons) {

              //Data from a specific query, but should really just show up on the graph, otherwise before this create the seed entity

              isFoundResult = true
              // Process data from possible person result

              logDebug(
                "possible persons size " + piplResponse.possible_persons.length
              );

              piplResponse.possible_persons.forEach((datum: any, index: any) => {
                logDebug("possible persons start");
                var possiblePersonEntity = this.result.addEntity(
                  uuidv4(),
                  schema.Person
                );
                setPersonEntityInfo(
                  possiblePersonEntity,
                  datum,
                  null,
                  true,
                  this.result
                );
                // possiblePersonEntity.setProperty(schema.Person.Display, datum.names[0].display);
                // possiblePersonEntity.setProperty(schema.Person.UniqueRef, id);
                // possiblePersonEntity.setProperty(schema.Person.PossiblePerson, true);
                // possiblePersonEntity.setProperty(schema.Person.AdditionalInfo, datum["@search_pointer"]);
                // if (seedEntity) {
                  
                //   this.result.addLink(
                //     seedEntity.id + "_" + possiblePersonEntity.id,
                //     schema.SubjectOf,
                //     seedEntity,
                //     possiblePersonEntity
                //   );
                // }

                if (seedEntity) {
                  logDebug("Adding a link between the person and the seed");
                  this.result.addLink(
                    seedEntity.id + "_" + possiblePersonEntity.id,
                    schema.SubjectOf,
                    seedEntity,
                    possiblePersonEntity
                  );
                }

                logDebug("possible persons end");

                //  Following line could be invoked by a checkbox to automatically expand - leaving off by default
                //processPersonData(datum, result, possiblePersonEntity);
              });
            }
          }
          else {
            console.log("Search Person service, got an error from Pipl API, or returned empty result")
            isFoundResult = false
          }
        })
        .catch((error: any) => {
          //this.result.status = "Warning";
          this.result.status = "At least some results were not available";
          console.log("Error in processPiplConnectorRequest: " + error);
        });

      //only if found a result then continue
      if (isFoundResult)
        break;
    }

    /*this.result.status = this.result.status || "OK";
    this.result.statusMessage = this.result.statusMessage || `Found some results`;  
    return this.result;*/
  }


  //https://stackoverflow.com/questions/51564001/how-to-make-axios-call-synchronous
  async runPiplAPIQuery(inputData: any) {
    try {
      //Here implement a retry on error, at least 3-5 times
      const call = axios.create({
        responseType: "json"
      });

      logDebug("data is " + inputData)

      var axios_config = {
        method: "post",
        url: "https://api.pipl.com/search/",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        data: inputData
      };

      return axios(axios_config).then((response: any) => {
        //logDebug("response is " + response.data)
        logDebug("response status is " + response.status)
        return response.data;
      }).catch((err:any) => {
        console.log("runpiplAPIQuery - error is " + err);
        if (err.response) {
          // client received an error response (5xx, 4xx)
          console.log("Caught error in runPiplAPIQuery: " + err.response);      
        } else if (err.request) {
          // client never received a response, or request never left
          console.log("Caught error in runPiplAPIQuery: " + err.request);
        } else {
          // anything else
        }
      });
    }
    catch(error) {
      console.log("Caught error in runPiplAPIQuery: " + error);
      return null;
    }
  }

}

export { PIPLConnector };
