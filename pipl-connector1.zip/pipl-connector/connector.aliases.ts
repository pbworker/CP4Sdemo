import { aliasProxyHandler, Aliases, BaseSchema, EntityType, LinkType } from 'connector-sdk';


// Entity Interfaces:
interface Company extends EntityType {
  Name: string,
  CompanyNumber: string,
  Status: string,
  Type: string,
  CessationDate: string,
  CreationDate: string,
  Description: string
}

interface Person extends EntityType {
  UniqueRef: string,
  Display: string,
  Forenames: string,
  Surname: string,
  Gender: string,
  DateOfBirth: string,
  Occupation: string,
  Nationality: string,
  CountryOfResidence: string,
  AdditionalInfo: string,
  PossiblePerson: string
}

interface Alias extends EntityType {
  valid_since: string;
  last_seen: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  prefix: string;
  suffix: string;
  type: string;
  display: string;
}

interface Email extends EntityType {
  valid_since: string;
  last_seen: string;
  type: string;
  email_provider: string;
  address: string;
  address_md5: string;
}

interface Username extends EntityType {
  valid_since: string;
  last_seen: string;
  content: string; 
}

interface Phone extends EntityType {
  valid_since: string;
  last_seen: string;
  type: string;
  do_not_call: string;
  country_code: string;
  number: string;
  display: string;
  display_international: string;
}

interface Job extends EntityType {
  valid_since: string;
  last_seen: string;
  title: string;
  organisation: string;
  industry: string;
  date_start: string;
  date_end: string;
  display: string;
}

interface Education extends EntityType {
  valid_since: string;
  last_seen: string;
  degree: string;
  school: string;
  date_start: string;
  date_end: string;
  display: string;
}

interface Relationship extends EntityType {
  valid_since: string;
  last_seen: string;
  type: string;
  subtype: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  display: string;
}

interface Images extends EntityType {
  valid_since: string;
  url: string;
  thumbnail_token: string;
}

interface Url extends EntityType {
  source_id: string;
  sponsored: string;
  domain: string;
  name: string;
  category: string;
  url: string;
}

interface Address extends EntityType {
  typeId: string;
  valid_since: string;
  last_seen: string;
  house: string;
  street: string;
  city: string;
  state: string;
  country: string;
  zipcode: string;
  display: string;
}

interface Event extends EntityType {
  Type: string;
  Category: string;
  From: string;
  To: string;
  Description: string;
}


interface CommsDevice extends EntityType {
  UniqueRef: string;
  DeviceType: string;
  InternationalCode: string;
  AreaCode: string;
  TelephoneNumber: string;
  AdditionalInformation: string;
}

interface Property extends EntityType {
  UniqueRef: string;
  PropertyType: string;
  Code: string;
  AdditionalInfo: string;
}

interface Vehicle extends EntityType {
  validSince: string,
  lastSeen: string,
  vin: string,
  make: string,
  model: string,
  type: string
}

// Link Interfaces:

interface AccessTo extends LinkType {
  UniqueRef: string,
  TypeOfUse: string,
  StartDateAndTime: string,
  EndDateAndTime: string
}

interface InvolvedIn extends LinkType {
  Type: string;
  overrides? :InvolvedIn[];
}

interface AddressOf extends LinkType {
  Type: string;
  overrides?: AddressOf[];
}

interface AlternativeName extends LinkType {
  Type: string;
  From: string;
  To: string;
}

interface CompanyRole extends LinkType{
  From: string;
  To: string;
  Type: string;
}

interface Associated extends LinkType {
  To: string;
  Type: string;
}

interface EmailLink extends LinkType {
  Type: string;
}

interface SubjectOf extends LinkType {
  Type: string;
}

// Pull entity and link type interfaces together into the Schema interface
interface Schema extends BaseSchema {
  // Aliases
  Company: Company;
  Person: Person;
  Alias: Alias;
  Email: Email;
  Username: Username;
  Phone: Phone;
  Job: Job;
  Education: Education;
  Relationship: Relationship;
  Images: Images;
  Url: Url;
  Address: Address;
  Event: Event;
  CommsDevice: CommsDevice;
  Property: Property;
  Vehicle: Vehicle;
  AccessTo: AccessTo;
  InvolvedIn: InvolvedIn;
  AddressOf: AddressOf;
  AlternativeName: AlternativeName;
  CompanyRole: CompanyRole;
  Associated: Associated;
  EmailLink: EmailLink;
  SubjectOf: SubjectOf;

}
// Different instance - in this case, will be mapped for the Framework.
const frameworkDefault: Schema = {
  DefaultEntity: {
    typeId: "i2.genericEntity"
  },
  DefaultLink: {
    typeId: "i2.genericLink"
  },
  Company: {
    typeId: "Company",
    Name: "Name",
    CompanyNumber: "Company Number",
    Status: "Status",
    Type: "Type",
    CessationDate: "Cessation Date",
    CreationDate: "Creation Date",
    Description: "Description"
  },

  Person: {
    typeId: "Person",
    UniqueRef: "UniqueRef",
    Display: "Full Name",
    Forenames: "Forenames",
    Surname: "Surname",
    Gender: "Gender",
    DateOfBirth: "DOB",
    Occupation: "Occupation",
    Nationality: "Nationality",
    CountryOfResidence: "CountryOfResidence",
    AdditionalInfo: "AdditionalInfo",
    PossiblePerson: "PossiblePerson"
  },

  Alias: {
    typeId: "Alias",
    valid_since: "valid_since",
    last_seen: "last_seen",
    first_name: "first_name",
    middle_name: "middle_name",
    last_name: "last_name",
    prefix: "prefix",
    suffix: "suffix",
    type: "type",
    display: "display"
  },

  Email: {
    typeId: "Email",
    valid_since: "valid_since",
    last_seen: "last_seen",
    type: "type",
    email_provider: "email_provider",
    address: "address",
    address_md5: "address_md5",
  },

  Username: {
    typeId: "Username",
    valid_since: "valid_since",
    last_seen: "last_seen",
    content: "content"
  },

  Phone: {
    typeId: "",
    valid_since: "",
    last_seen: "",
    type: "",
    do_not_call: "",
    country_code: "",
    number: "",
    display: "",
    display_international: ""
  },

  Job: {
    typeId: "",
    valid_since: "",
    last_seen: "",
    date_start: "",
    date_end: "",
    title: "",
    industry: "",
    organisation: "",
    display: ""
  },

  Education: {
    typeId: "",
    valid_since: "",
    last_seen: "",
    date_start: "",
    date_end: "",
    school: "",
    degree: "",
    display: ""
  },

  Relationship: {
    typeId: "",
    valid_since: "",
    last_seen: "",
    type: "",
    subtype: "",
    first_name: "",
    middle_name: "",
    last_name: "",
    display: "",
  },

  Images: {
    typeId: "",
    valid_since: "",
    url: "",
    thumbnail_token: "",
  },

  Url: {
    typeId: "",
    source_id: "",
    sponsored: "",
    name: "",
    category: "",
    domain: "",
    url: ""
  },

  Address: {
    typeId: "ET1",
    valid_since: "",
    last_seen: "",
    house: "",
    street: "",
    city: "",
    state: "",
    country: "ADD9",
    zipcode: "ADD8",
    display: "ADD5"
  },

  Event: {
    typeId: "Event",
    Type: "Type",
    Category: "Category",
    From: "From",
    To: "To",
    Description: "Description"
  },

  CommsDevice: {
    typeId: "CommsDevice",
    UniqueRef: "UniqueRef",
    DeviceType: "DeviceType",
    InternationalCode: "InternationalCode",
    AreaCode: "AreaCode",
    TelephoneNumber: "TelephoneNumber",
    AdditionalInformation: "AdditionalInformation"
  },

  Property: {
    typeId: "Property",
    UniqueRef: "UniqueRef",
    Code: "Code",
    PropertyType: "PropertyType",
    AdditionalInfo: "AdditionalInfo"
  },

  Vehicle: {
    typeId: "Vehicle",
    validSince: "ValidSince",
    lastSeen: "LastSince",
    vin: "VIN",
    make: "Make",
    model: "Model",
    type: "Type"
  },

  AccessTo: {
    typeId: "AccessTo",
    UniqueRef: "UniqueRef",
    TypeOfUse: "TypeOfUse",
    StartDateAndTime: "StartDateTime",
    EndDateAndTime: "EndDateTime"
  },

  InvolvedIn: {
    Type: "",
    typeId: "Occurred"
  },

  AddressOf: {
    typeId: "Address Of",
    Type: "Type"
  },

  AlternativeName: {
    typeId: "Previous Name",
    Type: "Type",
    From: "From",
    To: "To"
  },

  CompanyRole: {
    typeId: "Company Role",
    From: "From",
    To: "To",
    Type: "Type"
  },

  Associated: {
    typeId: "Associated",
    To: "To",
    Type: "Type"
  },

  EmailLink: {
    typeId: "",
    Type: ""
  },

  SubjectOf: {
    Type: "",
    typeId: "LSU1"
  }
};

const lawEnforcement: Schema = {
  DefaultEntity: {
    typeId: "ET5"
  },
  DefaultLink: {
    typeId: "LME1"
  },
  Relationship: {
    typeId: "ET5",
    valid_since: "",
    last_seen: "",
    type: "",
    subtype: "",
    first_name: "PER4",
    middle_name: "PER5",
    last_name: "PER6",
    display: "PER97",
  },
  Person: {
    typeId: "ET5",
    UniqueRef: "PER1",
    Display: "PER97",
    DateOfBirth: "PER9",
    Gender: "PER15",
    Forenames: "PER4",
    Surname: "PER6",
    CountryOfResidence: "PER93",
    Nationality: "PER13",
    Occupation: "PER28",
    AdditionalInfo: "PER50",
    PossiblePerson: ""
  },
  Alias: {
    typeId: "ET5",
    valid_since: "",
    last_seen: "",
    first_name: "PER4",
    middle_name: "PER5",
    last_name: "PER6",
    prefix: "PER3",
    suffix: "PER7",
    type: "PER50",
    display: "PER97"
  },
  Email: {
    typeId: "ET9",
    valid_since: "PRO50",
    last_seen: "",
    type: "PRO2",
    email_provider: "PRO4",
    address: "PRO1",
    address_md5: "",
  },
  Username: {
    typeId: "ET9",
    valid_since: "PRO50",
    last_seen: "PRO1",
    content: "PRO2"
  },
  Phone: {
    typeId: "ET8",
    valid_since: "",
    last_seen: "",
    type: "COM2",
    do_not_call: "",
    country_code: "COM4",
    number: "COM6",
    display: "COM6",
    display_international: "COM16"
  },
  Job: {
    typeId: "ET4",
    valid_since: "",
    last_seen: "",
    date_start: "",
    date_end: "",
    title: "",
    industry: "ORG3",
    organisation: "ORG2",
    display: ""
  },
  Education: {
    typeId: "ET4",
    valid_since: "",
    last_seen: "",
    date_start: "",
    date_end: "",
    school: "ORG2",
    degree: "ORG3",
    display: ""
  },
  Company: {
    typeId: "ET4",
    Name: "ORG2", 
    CompanyNumber: "ORG11",
    CreationDate: "ORG5",
    CessationDate: "ORG6",
    
    Description: "ORG7",
    Status: "ORG12",  
    Type: "ORG3"
  },
  Images: {
    typeId: "ET6",
    valid_since: "",
    url: "INT17",
    thumbnail_token: "INT13",
  },
  Url: {
    typeId: "ET6",
    source_id: "",
    sponsored: "",
    name: "INT15",
    category: "INT14",
    domain: "INT4",
    url: "INT17"
  },
  Address: {
    typeId: "ET1",
    valid_since: "",
    last_seen: "",
    house: "ADD3",
    street: "ADD5",
    city: "ADD6",
    state: "ADD17",
    country: "ADD9",
    zipcode: "ADD8",
    display: "ADD5"
  },

  Event: {
    typeId: "ET2",
    Type: "EVE3",
    Category: "EVE8",
    From: "EVE4",
    To: "EVE5", 
    Description: "EVE6"
  },

  CommsDevice: {
    typeId: "ET8",
    UniqueRef: "COM1",
    DeviceType: "COM2",
    InternationalCode: "COM4",
    AreaCode: "COM5",
    TelephoneNumber: "COM6",
    AdditionalInformation: "COM16"
  },

  Property: {
    typeId: "ET9",
    UniqueRef: "PRO1",
    Code: "PRO3",
    PropertyType: "PRO2",
    AdditionalInfo: "PRO50"
  },

  Vehicle: {
    typeId: "ET3",
    validSince: "",
    lastSeen: "",
    vin: "VEH38",
    make: "VEH4",
    model: "VEH5",
    type: ""
  },

  AccessTo: {
    typeId: "LAC1",
    UniqueRef: "LAC2",
    TypeOfUse: "LAC3",
    StartDateAndTime: "LAC5",
    EndDateAndTime: "LAC7"
  },

  InvolvedIn: {
    Type: "",
    typeId: "LIN1"
  },

  AddressOf: {
    typeId: "LAC1",
    Type: "LAC3"
  },

  AlternativeName: {
    typeId: "LDU1",
    Type: "LDU3",
    From: "",
    To: ""
  },

  // Not a great match but the LE Schema is not really designed for this
  CompanyRole: {
    typeId: "LAC1",
    From: "LAC5",
    To: "LAC7",
    Type: "LAC3"
  },

  Associated: {
    typeId: "LAS1",
    To: "LAS6",
    Type: "LAS4"
  },

  EmailLink: {
    typeId: "LAC1",
    Type: "LAC3"
  },
  SubjectOf: {
    Type: "",
    typeId: "LSU1"
  }
}

const pipl: Schema = {
  Files: {
    SchemaFile: "pipl-schema.xml",
    ChartingSchemesFile: "pipl-schema-ChartingSchemes.xml",
  },
  
  SchemaShortName: "pipl2",

  DefaultEntity: {
    typeId: "ET1"
  },
  DefaultLink: {
    typeId: "LT1"
  },
  Relationship: {
    typeId: "ET12",
    valid_since: "PT87",
    last_seen: "PT88",
    type: "PT89",
    subtype: "PT90",
    first_name: "PT86",
    middle_name: "PT91",
    last_name: "PT92",
    display: "PT93",
  },
  Person: {
    typeId: "ET1",
    UniqueRef: "PT1",
    Display: "PT66",
    DateOfBirth: "PT6",
    Gender: "PT5",
    Forenames: "PT3",
    Surname: "PT4",
    CountryOfResidence: "",
    Nationality: "",
    Occupation: "",
    AdditionalInfo: "PT7",
    PossiblePerson: "PT75"
  },
  Alias: {
    typeId: "ET11",
    valid_since: "PT76",
    last_seen: "PT77",
    first_name: "PT78",
    middle_name: "PT79",
    last_name: "PT80",
    prefix: "PT81",
    suffix: "PT82",
    type: "PT83",
    display: "PT84"
  },
  Email: {
    typeId: "ET2",
    valid_since: "PT8",
    last_seen: "PT9",
    type: "PT10",
    email_provider: "PT11",
    address: "PT12",
    address_md5: "PT13",
  },
  Username: {
    typeId: "ET3",
    valid_since: "PT14",
    last_seen: "PT15",
    content: "PT16"
  },
  Phone: {
    typeId: "ET4",
    valid_since: "PT17",
    last_seen: "PT18",
    type: "PT67",
    do_not_call: "PT23",
    country_code: "PT20",
    number: "PT21",
    display: "PT22",
    display_international: "PT23"
  },
  Job: {
    typeId: "ET5",
    valid_since: "PT24",
    last_seen: "PT25",
    date_start: "PT28",
    date_end: "PT29",
    title: "PT26",
    industry: "PT31",
    organisation: "PT27",
    display: "PT30"
  },
  Education: {
    typeId: "ET6",
    valid_since: "PT32",
    last_seen: "PT33",
    date_start: "PT36",
    date_end: "PT37",
    school: "PT35",
    degree: "PT34",
    display: "PT38"
  },
  Company: {
    typeId: "",
    Name: "", 
    CompanyNumber: "",
    CreationDate: "",
    CessationDate: "",
    Description: "",
    Status: "",  
    Type: ""
  },
  Images: {
    typeId: "ET7",
    valid_since: "PT39",
    url: "PT41",
    thumbnail_token: "PT42",
  },
  Url: {
    typeId: "ET8",
    source_id: "PT43",
    sponsored: "",
    name: "PT45",
    category: "PT46",
    domain: "PT44",
    url: "PT47"
  },
  Address: {
    typeId: "ET9",
    valid_since: "PT48",
    last_seen: "PT49",
    house: "PT55",
    street: "PT54",
    city: "PT53",
    state: "PT52",
    country: "PT51",
    zipcode: "PT56",
    display: "PT57"
  },

  Event: {
    typeId: "",
    Type: "",
    Category: "",
    From: "",
    To: "", 
    Description: ""
  },

  CommsDevice: {
    typeId: "",
    UniqueRef: "",
    DeviceType: "",
    InternationalCode: "",
    AreaCode: "",
    TelephoneNumber: "",
    AdditionalInformation: ""
  },

  Property: {
    typeId: "",
    UniqueRef: "",
    Code: "",
    PropertyType: "",
    AdditionalInfo: ""
  },

  Vehicle: {
    typeId: "ET10",
    validSince: "PT73",
    lastSeen: "PT74",
    vin: "PT70",
    make: "PT71",
    model: "PT72",
    type: "PT85"
  },

  AccessTo: {
    typeId: "LT1",
    UniqueRef: "PT58",
    TypeOfUse: "PT59",
    StartDateAndTime: "PT62",
    EndDateAndTime: "PT63"
  },

  InvolvedIn: {
    typeId: "LT1",
    Type: "PT59"
  },

  AddressOf: {
    typeId: "LT1",
    Type: "PT59"
  },

  AlternativeName: {
    typeId: "LT1",
    Type: "PT59",
    From: "",
    To: ""
  },

  // Not a great match but the LE Schema is not really designed for this
  CompanyRole: {
    typeId: "LT1",
    From: "PT60",
    To: "PT61",
    Type: "PT59"
  },

  Associated: {
    typeId: "LT1",
    To: "PT61",
    Type: "PT59"
  },

  EmailLink: {
    typeId: "LT1",
    Type: "PT59"
  },
  SubjectOf: {
    typeId: "LT1",
    Type: "PT59"
  }
}

const intel: Schema = {

  SchemaShortName: "intel",

  DefaultEntity: {
    typeId: "ET1"
  },
  DefaultLink: {
    typeId: "LIN1"
  },
  Relationship: {
    typeId: "ET12",
    valid_since: "PT87",
    last_seen: "PT88",
    type: "PT89",
    subtype: "PT90",
    first_name: "PT86",
    middle_name: "PT91",
    last_name: "PT92",
    display: "PT93",
  },
  Person: {
    typeId: "ET1",
    UniqueRef: "PT1",
    Display: "PT66",
    DateOfBirth: "PT6",
    Gender: "PT5",
    Forenames: "PT3",
    Surname: "PT4",
    CountryOfResidence: "",
    Nationality: "",
    Occupation: "",
    AdditionalInfo: "PT7",
    PossiblePerson: "PT75"
  },
  Alias: {
    typeId: "ET11",
    valid_since: "PT76",
    last_seen: "PT77",
    first_name: "PT78",
    middle_name: "PT79",
    last_name: "PT80",
    prefix: "PT81",
    suffix: "PT82",
    type: "PT83",
    display: "PT84"
  },
  Email: {
    typeId: "ET2",
    valid_since: "PT8",
    last_seen: "PT9",
    type: "PT10",
    email_provider: "PT11",
    address: "PT12",
    address_md5: "PT13",
  },
  Username: {
    typeId: "ET3",
    valid_since: "PT14",
    last_seen: "PT15",
    content: "PT16"
  },
  Phone: {
    typeId: "ET4",
    valid_since: "PT17",
    last_seen: "PT18",
    type: "PT67",
    do_not_call: "PT23",
    country_code: "PT20",
    number: "PT21",
    display: "PT22",
    display_international: "PT23"
  },
  Job: {
    typeId: "ET5",
    valid_since: "PT24",
    last_seen: "PT25",
    date_start: "PT28",
    date_end: "PT29",
    title: "PT26",
    industry: "PT31",
    organisation: "PT27",
    display: "PT30"
  },
  Education: {
    typeId: "ET6",
    valid_since: "PT32",
    last_seen: "PT33",
    date_start: "PT36",
    date_end: "PT37",
    school: "PT35",
    degree: "PT34",
    display: "PT38"
  },
  Company: {
    typeId: "",
    Name: "", 
    CompanyNumber: "",
    CreationDate: "",
    CessationDate: "",
    Description: "",
    Status: "",  
    Type: ""
  },
  Images: {
    typeId: "ET7",
    valid_since: "PT39",
    url: "PT41",
    thumbnail_token: "PT42",
  },
  Url: {
    typeId: "ET8",
    source_id: "PT43",
    sponsored: "",
    name: "PT45",
    category: "PT46",
    domain: "PT44",
    url: "PT47"
  },
  Address: {
    typeId: "ET9",
    valid_since: "PT48",
    last_seen: "PT49",
    house: "PT55",
    street: "PT54",
    city: "PT53",
    state: "PT52",
    country: "PT51",
    zipcode: "PT56",
    display: "PT57"
  },

  Event: {
    typeId: "",
    Type: "",
    Category: "",
    From: "",
    To: "", 
    Description: ""
  },

  CommsDevice: {
    typeId: "",
    UniqueRef: "",
    DeviceType: "",
    InternationalCode: "",
    AreaCode: "",
    TelephoneNumber: "",
    AdditionalInformation: ""
  },

  Property: {
    typeId: "",
    UniqueRef: "",
    Code: "",
    PropertyType: "",
    AdditionalInfo: ""
  },

  Vehicle: {
    typeId: "ET10",
    validSince: "PT73",
    lastSeen: "PT74",
    vin: "PT70",
    make: "PT71",
    model: "PT72",
    type: "PT85"
  },

  AccessTo: {
    typeId: "LT1",
    UniqueRef: "PT58",
    TypeOfUse: "PT59",
    StartDateAndTime: "PT62",
    EndDateAndTime: "PT63"
  },

  InvolvedIn: {
    typeId: "LT1",
    Type: "PT59"
  },

  AddressOf: {
    typeId: "LT1",
    Type: "PT59"
  },

  AlternativeName: {
    typeId: "LT1",
    Type: "PT59",
    From: "",
    To: ""
  },

  // Not a great match but the LE Schema is not really designed for this
  CompanyRole: {
    typeId: "LT1",
    From: "PT60",
    To: "PT61",
    Type: "PT59"
  },

  Associated: {
    typeId: "LT1",
    To: "PT61",
    Type: "PT59"
  },

  EmailLink: {
    typeId: "LT1",
    Type: "PT59"
  },
  SubjectOf: {
    typeId: "LT1",
    Type: "PT59"
  }
}

// Create a new Proxy for the Schema
export const schema: Schema = new Proxy(<Schema>{}, aliasProxyHandler);

export const aliases: any = { frameworkDefault, lawEnforcement, pipl, intel };


