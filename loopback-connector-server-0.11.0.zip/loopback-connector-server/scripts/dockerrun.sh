SCRIPT_HOME="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# Clear down old containers
docker rm -f loopback-connector-server

# Remove old volumes
docker volume rm `docker volume ls -q -f dangling=true`

# Remove old docker networks
docker network rm lcsnet &>/dev/null || true


# Create the docker network
echo "Creating docker network lcsnet."
docker network create lcsnet

# Startup LCS container
echo "Starting up LCS container."
docker run -m 512m -d \
            --name loopback-connector-server \
            --network lcsnet \
            -p 3000:3000 \
            loopback-image:latest tail -f /dev/null

echo "Starting up LCS container."
docker cp ${SCRIPT_HOME}/../deploy/connectors/ loopback-connector-server:/home/node/app/deploy/connectors

docker exec loopback-connector-server /home/node/app/scripts/start.sh