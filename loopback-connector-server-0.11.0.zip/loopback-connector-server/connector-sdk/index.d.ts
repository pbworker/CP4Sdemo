export declare class Logger implements ILogger {
    private logLevel;
    private logDir;
    private logger;
    constructor(logLevel?: string, logDir?: string);
    error(message: any): void;
    warn(message: any): void;
    info(message: any): void;
    verbose(message: any): void;
    debug(message: any): void;
    silly(message: any): void;
}
export declare let LOGGER: Logger;
export declare function setLogger(logger: Logger): void;
export declare enum SubstatusTypeEnum {
    SUCCESS = "success",
    INFORMATION = "information",
    WARNING = "warning",
    ERROR = "error"
}
export declare enum LogicalType {
    SINGLE_LINE_STRING = "SINGLE_LINE_STRING",
    MULTIPLE_LINE_STRING = "MULTIPLE_LINE_STRING",
    SUGGESTED_FROM = "SUGGESTED_FROM",
    SELECTED_FROM = "SELECTED_FROM",
    DECIMAL = "DECIMAL",
    DOUBLE = "DOUBLE",
    INTEGER = "INTEGER",
    BOOLEAN = "BOOLEAN",
    DATE = "DATE",
    TIME = "TIME",
    DATE_AND_TIME = "DATE_AND_TIME",
    EXTERNAL_URL = "EXTERNAL_URL",
    GEOSPATIAL = "GEOSPATIAL"
}
export declare enum AllowedTypes {
    ENTITY = "ENTITY",
    LINK = "LINK"
}
export declare enum Status {
    OK = "OK",
    Error = "Error",
    Warning = "Warning"
}
export declare enum Direction {
    NONE = "NONE",
    WITH = "WITH",
    AGAINST = "AGAINST",
    BOTH = "BOTH"
}
export interface ILogger {
    error(message: string | any): void;
    warn(message: string | any): void;
    info(message: string | any): void;
    verbose(message: string | any): void;
    debug(message: string | any): void;
    silly(message: string | any): void;
}
export interface ItemType {
    typeId: string;
}
export interface SchemaFiles {
    SchemaFile: string;
    ChartingSchemesFile: string;
}
export interface BaseSchema {
    DefaultEntity: EntityType;
    DefaultLink: LinkType;
    Extension?: any[];
    Files?: SchemaFiles;
    SchemaShortName?: string;
}
export interface LinkType extends ItemType {
    fromType?: EntityType;
    toType?: EntityType;
    overrides?: LinkType[];
}
export interface EntityType extends ItemType {
}
export declare class SeedEntity {
    private _identity;
    private _connectorKeys;
    private _otherKeys;
    private _properties;
    private _label;
    private _rawSeed;
    private _type;
    constructor(identity: string, connectorKeys: SeedKey[], otherKeys: SeedKey[], properties: any, label: string, rawSeed: any, type: EntityType | string);
    get identity(): string;
    get connectorKeys(): readonly SeedKey[];
    get otherKeys(): readonly SeedKey[];
    get label(): string;
    get rawSeed(): any;
    get type(): EntityType | string;
    connectorKeysByType(type: EntityType): readonly SeedKey[];
    otherKeysByType(type: EntityType | string): readonly SeedKey[];
    propertyNames(): readonly string[];
    hasProperty(name: string): boolean;
    getProperty(name: string): any | undefined;
}
export declare class SeedKey {
    private _connectorId;
    private _type;
    private _id;
    private _transportId?;
    constructor(connectorId: string, type: EntityType | string, id: string, transportId?: string);
    get connectorId(): string;
    get type(): EntityType | string;
    get id(): string;
    get transportId(): string | undefined;
}
export interface ISubstatus {
    type: SubstatusTypeEnum;
    message: string;
}
export declare class AsyncState {
    protected _canceled: boolean;
    protected _substatuses: ISubstatus[];
    protected _message: string;
    protected _summary: string;
    constructor();
    isCanceled(): boolean;
    setMessage(message: string): void;
    setSummary(summary: string): void;
    addSubstatus(type: SubstatusTypeEnum, message: string): ISubstatus;
    clearSubstatuses(): void;
}
export declare class ServerAsyncState extends AsyncState {
    get substatuses(): ISubstatus[];
    get message(): string;
    get summary(): string;
    set canceled(canceled: boolean);
}
export declare class Seeds {
    private _entities;
    constructor(entities: SeedEntity[]);
    get entities(): readonly SeedEntity[];
}
export declare function createProductSeeds(connectorId: string, rawSeeds: any, aliasId: string, dealiases: DeAliases): Seeds;
export declare function createFrameworkSeeds(connectorId: string, rawSeeds: any, aliasId: string, dealiases: DeAliases): Seeds;
declare class Properties {
    asAliasedProperties(aliasedIitemType: EntityType | LinkType): any;
}
export declare class Entity {
    private _id?;
    private _transportId?;
    private _type?;
    private readonly properties;
    private _identity?;
    private _seed?;
    private _sourceReference;
    constructor(id: string | undefined, type: EntityType | undefined, seed: SeedEntity | undefined);
    get id(): string | undefined;
    get type(): EntityType | undefined;
    get identity(): string | undefined;
    get transportId(): string | undefined;
    set identity(value: string | undefined);
    get seed(): SeedEntity | undefined;
    setSourceReference(id: string, name: string, type: string | undefined, locationUrl: string | undefined, imageUrl: string | undefined, description: string | undefined): void;
    setProperty(propertyName: string, propertyValue: any): void;
    setProperties(properties: any): void;
    private toAliasedNonSeedEntity;
    toFrameworkEntity(aliases: Aliases, aliasId: string): any;
    toProductEntity(aliases: Aliases, aliasId: string): any;
    toTestEntity(): {
        id: string | undefined;
        typeId: any;
        type?: undefined;
        properties?: undefined;
    } | {
        id: string | undefined;
        type: EntityType | undefined;
        properties: any;
        typeId?: undefined;
    };
}
export declare class Link {
    _id: string;
    _type: LinkType;
    private readonly properties;
    _fromEnd: Entity;
    _toEnd: Entity;
    _linkDirection: string | Direction;
    private _sourceReference;
    constructor(id: string, type: LinkType, fromEnd: Entity, toEnd: Entity, linkDirection: string | Direction);
    get id(): string | undefined;
    get type(): LinkType;
    get fromEnd(): Entity;
    get toEnd(): Entity;
    get linkDirection(): string | Direction;
    set linkDirection(value: string | Direction);
    setSourceReference(id: string, name: string, type: string | undefined, locationUrl: string | undefined, imageUrl: string | undefined, description: string | undefined): void;
    setProperty(propertyName: string, propertyValue: any): void;
    setProperties(properties: any): void;
    private toAliasedLink;
    toFrameworkLink(aliases: Aliases, aliasId: string): any;
    toProductLink(aliases: Aliases, aliasId: string): any;
    toTestLink(): {
        id: string | undefined;
        type: LinkType;
        linkDirection: string;
        fromEndId: string | undefined;
        toEndId: string | undefined;
        properties: Properties;
    };
}
export declare class Result {
    status?: string | Status;
    statusMessage?: string;
    private entityMap;
    private linkMap;
    private infoStoreLinkMap;
    addInfoStoreEntity(recordId: string): Entity;
    addInfoStoreLink(recordId: string): void;
    addLink(id: string, type: LinkType, fromEnd: Entity, toEnd: Entity): Link;
    addEntity(id: string, type: EntityType): Entity;
    addEntityFromSeed(seed: SeedEntity): Entity;
    toFrameworkResult(connectorId: string, aliases: Aliases, aliasId: string): any;
    toProducctResult(aliases: Aliases, aliasId: string): any;
    toTestResult(): any;
}
declare class SimpleSeedConstraints {
    private _connectorId?;
    private _metadata;
    constructor(metadata: SimpleSeedConstraintsMetadata);
    get isSimpleSeedConstraints(): boolean;
    get connectorId(): string | undefined;
    set connectorId(value: string | undefined);
    get metadata(): SimpleSeedConstraintsMetadata;
    asProductSeedsConstraints(aliases: Aliases, aliasId: string): any;
}
export interface SimpleSeedConstraintsMetadata {
    thisConnectorOnly?: boolean;
    types: (EntityType | string)[];
    min?: number;
    max?: number;
}
declare class FullSeedConstraints {
    private _metadata;
    constructor(metadata: FullSeedConstraintsMetadata);
    get isSimpleSeedConstraints(): boolean;
    get metadata(): FullSeedConstraintsMetadata;
    asProductSeedsConstraints(aliases: Aliases, aliasId: string): {
        seedTypes: {
            allowedTypes: string;
            itemTypes: {
                id: string;
                min: number;
                max: number;
            }[] | undefined;
        } | undefined;
        min: number | undefined;
        max: number | undefined;
        connectorIds: string[] | undefined;
    };
}
export interface FullSeedConstraintsMetadata {
    seedTypes?: {
        allowedTypes: string;
        itemTypes?: {
            id: EntityType | LinkType;
            min: number;
            max: number;
        }[];
    };
    min?: number;
    max?: number;
    connectorIds?: string[];
}
export declare const configMap: Map<string, Config>;
export interface ConnectorMetadata {
    name?: string;
    description?: string;
    defaultTimeZoneId?: string;
    defaultEntityType?: ItemType;
    defaultLinkType?: ItemType;
}
export interface ServiceMetadata {
    name?: string;
    description?: string;
    iconUrl?: string;
    mergeBehavior?: string;
    async?: boolean;
}
export interface PossibleValue {
    displayName: string;
    value: string;
}
interface Validation {
    regex: string;
    message: string;
}
interface BaseConditionMetadata {
    label?: string;
    description?: string;
    mandatory?: boolean;
}
interface SingleLineStringConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.SINGLE_LINE_STRING;
    validation?: Validation;
    defaultValue?: string;
}
interface SuggestedFromConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.SUGGESTED_FROM;
    possibleValues: PossibleValue[];
    defaultValue?: string;
}
interface SelectedFromConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.SELECTED_FROM;
    possibleValues: PossibleValue[];
    isMultiSelect?: boolean;
    defaultValue?: string;
}
interface NumberConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.INTEGER | LogicalType.DECIMAL | LogicalType.DOUBLE;
    minValue?: number;
    maxValue?: number;
    defaultValue?: number;
}
interface ExternalUrlConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.EXTERNAL_URL;
    externalUrlRef?: string;
}
interface BooleanConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.BOOLEAN;
    defaultValue?: boolean;
}
interface GeospatialConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.GEOSPATIAL;
}
interface MultiLineStringConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.MULTIPLE_LINE_STRING;
    validation?: Validation;
    defaultValue?: string;
}
interface DateAndTimeConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.DATE_AND_TIME;
}
interface DateConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.DATE;
    defaultValue?: string;
}
interface TimeConditionMetadata extends BaseConditionMetadata {
    logicalType: LogicalType.TIME;
    defaultValue?: string;
}
export declare type ConditionMetadata = SingleLineStringConditionMetadata | MultiLineStringConditionMetadata | SuggestedFromConditionMetadata | SelectedFromConditionMetadata | NumberConditionMetadata | DateConditionMetadata | DateAndTimeConditionMetadata | TimeConditionMetadata | ExternalUrlConditionMetadata | BooleanConditionMetadata | GeospatialConditionMetadata;
export declare class Config {
    metadata: ConnectorMetadata;
    services: Service[];
    id: string;
    constructor(metadata: ConnectorMetadata, services: Service[], id: string);
    getService(id: string): Service | undefined;
    createAttributeMappings(itemTypeProperty: string, itemType: any): any[];
    createAttributes(alias: any): {
        id: string;
        name: string;
        type: string;
        show: boolean;
        prefix: string;
        suffix: string;
    }[];
    createItemMappings(alias: any): {
        typeId: any;
        propertyMappings: {
            name: string;
            propertyId: string | null;
            defaultValue: any;
        }[];
        attributeMappings: any[];
    }[];
    createChartingSchemes(alias: any, aliasId: string): any[];
    asFrameworkConnector(aliases: Aliases, aliasId: string, schema: BaseSchema): any;
    asProductConnector(aliases: Aliases, aliasId: string, schema: BaseSchema, allowCustom: boolean): any;
}
export declare class Service {
    metadata: ServiceMetadata;
    id: string;
    conditions: Condition[];
    seedConstraints: SimpleSeedConstraints | FullSeedConstraints | undefined;
    includeJWT: boolean;
    includeAsyncState: boolean;
    customConditionsStatus: "NO_CUSTOM" | "IGNORABLE" | "REQUIRED";
    constructor(metadata: ServiceMetadata, id: string, conditions: Condition[], seedConstraints: SimpleSeedConstraints | FullSeedConstraints | undefined, includeJWT: boolean, includeAsyncState: boolean);
    includesJWT(): boolean;
    includesAsyncState(): boolean;
    takesSeeds(): boolean;
    convertConditionsToParams(incomingConditions: any[]): (any | undefined)[];
    private isRequiredCustomForm;
    private isIgnorableCustomForm;
    identifyCustomStatus(): void;
    asFrameworkService(configId: string, aliasId: string): any;
    asProductService(configId: string, aliases: Aliases, aliasId: string, allowCustom: boolean): any;
    asFrameworkForm(): any;
    asProductClientConfig(allowCustom: boolean): any;
}
declare class Condition {
    metadata: ConditionMetadata;
    parameterIndex: number;
    constructor(metadata: ConditionMetadata, parameterIndex: number);
    private asBaseCondition;
    asFrameworkCondition(): any;
    asProductCondition(allowCustom: boolean): any;
}
export declare function connector(metadata: ConnectorMetadata): (constructor: Function) => void;
export declare function service(metadata: ServiceMetadata): (target: any, propertyKey: string, descriptor: PropertyDescriptor) => void;
export declare function condition(metadata: ConditionMetadata): (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;
export declare function jwt(): (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;
export declare function asyncState(): (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;
export declare function seeds(metadata: SimpleSeedConstraintsMetadata | FullSeedConstraintsMetadata): (target: Object, propertyKey: string | symbol, parameterIndex: number) => void;
export interface AliasedConnector {
    getAliases(): Aliases;
    getSchema(): BaseSchema;
    getDir?(): string;
}
export declare class DeAliases {
    private itemDeAliasMap;
    private propertyDeAliasMap;
    private aliasesObj;
    constructor(aliasesObj: Aliases, schema: BaseSchema | {});
    withoutShortnameSuffixIfPresent(aliasesId: string, itemAliasId: string): string;
    itemType(aliasesId: string, itemAliasId: string): EntityType | LinkType | string;
    hasProperty(aliasesId: string, itemAliasId: string, propertyAliasId: string): boolean;
    hasPropertyIgnoreSpaces(aliasesId: string, itemAliasId: string, propertyAliasId: string): boolean;
    property(aliasesId: string, itemAliasId: string, propertyAliasId: string): string;
    propertyIgnoreSpaces(aliasesId: string, itemAliasId: string, propertyAliasId: string): string;
}
export declare class Aliases {
    aliases: any;
    private aliasesIds;
    constructor(aliases: any);
    hasAlias(aliasesId: string): boolean;
    alias(aliasesId: string): any;
    private itemAlias;
    itemType(aliasesId: string, itemType: EntityType | LinkType | string): EntityType | LinkType;
    overrideLinkType(linkType: LinkType, fromEndType: EntityType, toEndType: EntityType): LinkType | undefined;
    item(aliasesId: string, itemAliasId: string): string;
    entityProperty(aliasesId: string, alias: string): string;
}
export declare const aliasProxyHandler: {
    get(itemTarget: any, itemProp: string): any;
};
export {};
