"use strict";
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const winston = __importStar(require("winston"));
/*
 * Not ideal having implementatioin here but want to ensure that this is the only thing
 * you need to include to write a connector, keeping apart from server code.
 */
class Logger {
    constructor(logLevel = 'debug', logDir = "../logs") {
        this.logLevel = logLevel;
        this.logDir = logDir;
        this.logger = winston.createLogger({
            level: logLevel,
            transports: [
                //
                // - Write to all logs with level `info` and below to `combined.log` 
                // - Write all logs error (and below) to `error.log`.
                //
                new winston.transports.File({
                    filename: `${logDir}/i2ConnectorServer.log`,
                    format: winston.format.combine(winston.format.timestamp({
                        format: 'YYYY-MM-DD HH:mm:ss'
                    }), winston.format.simple())
                })
            ]
        });
        // Only add console if not in production 
        if (process.env.NODE_ENV !== 'production') {
            this.logger.add(new winston.transports.Console({
                level: logLevel,
                format: winston.format.combine(winston.format.colorize(), winston.format.simple())
            }));
        }
    }
    error(message) {
        this.logger.error(message);
    }
    warn(message) {
        this.logger.warn(message);
    }
    info(message) {
        this.logger.info(message);
    }
    verbose(message) {
        this.logger.verbose(message);
    }
    debug(message) {
        this.logger.debug(message);
    }
    silly(message) {
        this.logger.silly(message);
    }
}
exports.Logger = Logger;
const infoStorePrefix = 'infoStoreRecordId:';
exports.LOGGER = new Logger();
function setLogger(logger) {
    exports.LOGGER = logger;
}
exports.setLogger = setLogger;
var SubstatusTypeEnum;
(function (SubstatusTypeEnum) {
    SubstatusTypeEnum["SUCCESS"] = "success";
    SubstatusTypeEnum["INFORMATION"] = "information";
    SubstatusTypeEnum["WARNING"] = "warning";
    SubstatusTypeEnum["ERROR"] = "error";
})(SubstatusTypeEnum = exports.SubstatusTypeEnum || (exports.SubstatusTypeEnum = {}));
var LogicalType;
(function (LogicalType) {
    LogicalType["SINGLE_LINE_STRING"] = "SINGLE_LINE_STRING";
    LogicalType["MULTIPLE_LINE_STRING"] = "MULTIPLE_LINE_STRING";
    LogicalType["SUGGESTED_FROM"] = "SUGGESTED_FROM";
    LogicalType["SELECTED_FROM"] = "SELECTED_FROM";
    LogicalType["DECIMAL"] = "DECIMAL";
    LogicalType["DOUBLE"] = "DOUBLE";
    LogicalType["INTEGER"] = "INTEGER";
    LogicalType["BOOLEAN"] = "BOOLEAN";
    LogicalType["DATE"] = "DATE";
    LogicalType["TIME"] = "TIME";
    LogicalType["DATE_AND_TIME"] = "DATE_AND_TIME";
    LogicalType["EXTERNAL_URL"] = "EXTERNAL_URL";
    LogicalType["GEOSPATIAL"] = "GEOSPATIAL"; // Product only
})(LogicalType = exports.LogicalType || (exports.LogicalType = {}));
var AllowedTypes;
(function (AllowedTypes) {
    AllowedTypes["ENTITY"] = "ENTITY";
    AllowedTypes["LINK"] = "LINK";
})(AllowedTypes = exports.AllowedTypes || (exports.AllowedTypes = {}));
var Status;
(function (Status) {
    Status["OK"] = "OK";
    Status["Error"] = "Error";
    Status["Warning"] = "Warning";
})(Status = exports.Status || (exports.Status = {}));
var Direction;
(function (Direction) {
    Direction["NONE"] = "NONE";
    Direction["WITH"] = "WITH";
    Direction["AGAINST"] = "AGAINST";
    Direction["BOTH"] = "BOTH";
})(Direction = exports.Direction || (exports.Direction = {}));
class SeedEntity {
    constructor(identity, connectorKeys, otherKeys, properties, label, rawSeed, type) {
        this._connectorKeys = [];
        this._otherKeys = [];
        this._properties = {};
        this._identity = identity;
        this._connectorKeys = connectorKeys;
        this._otherKeys = otherKeys;
        this._properties = properties;
        this._label = label;
        this._rawSeed = rawSeed;
        this._type = type;
    }
    get identity() {
        return this._identity;
    }
    get connectorKeys() { return this._connectorKeys; }
    get otherKeys() { return this._otherKeys; }
    ;
    get label() { return this._label; }
    get rawSeed() { return this._rawSeed; }
    get type() { return this._type; }
    connectorKeysByType(type) {
        return this.connectorKeys.filter(x => x.type === type);
    }
    otherKeysByType(type) {
        return this.otherKeys.filter(x => x.type === type);
    }
    propertyNames() {
        return Object.keys(this._properties);
    }
    hasProperty(name) {
        return this._properties.hasOwnProperty(name);
    }
    getProperty(name) {
        if (!this._properties[name]) {
            exports.LOGGER.verbose(`Warning: property ${name} is not present on seed. This may be because it is not mapped`);
        }
        return this._properties[name];
    }
}
exports.SeedEntity = SeedEntity;
class SeedKey {
    constructor(connectorId, type, id, transportId) {
        this._connectorId = connectorId;
        this._type = type;
        this._id = id;
        this._transportId = transportId;
    }
    get connectorId() { return this._connectorId; }
    get type() { return this._type; }
    get id() { return this._id; }
    get transportId() { return this._transportId; }
}
exports.SeedKey = SeedKey;
class AsyncState {
    constructor() {
        this._canceled = false;
        this._substatuses = [];
    }
    isCanceled() {
        return this._canceled;
    }
    setMessage(message) {
        this._message = message;
    }
    setSummary(summary) {
        this._summary = summary;
    }
    addSubstatus(type, message) {
        const substatus = { type, message };
        this._substatuses.push(substatus);
        return substatus;
    }
    clearSubstatuses() {
        this._substatuses = [];
    }
}
exports.AsyncState = AsyncState;
class ServerAsyncState extends AsyncState {
    get substatuses() {
        return this._substatuses;
    }
    get message() {
        return this._message;
    }
    get summary() {
        return this._summary;
    }
    set canceled(canceled) {
        this._canceled = canceled;
    }
}
exports.ServerAsyncState = ServerAsyncState;
class Seeds {
    constructor(entities) {
        this._entities = [];
        this._entities = entities;
    }
    get entities() { return this._entities; }
}
exports.Seeds = Seeds;
function createProductSeeds(connectorId, rawSeeds, aliasId, dealiases) {
    const entities = [];
    if (rawSeeds) {
        for (const seed of rawSeeds.entities) {
            const connectorKeys = [];
            const otherKeys = [];
            if (seed.sourceIds) {
                for (const sourceId of seed.sourceIds) {
                    const fixedUpSourceId = dealiases.withoutShortnameSuffixIfPresent(aliasId, sourceId.key[1]); // can be removed when bug fixed
                    const entityType = dealiases.itemType(aliasId, fixedUpSourceId);
                    const seedKey = new SeedKey(sourceId.key[0], entityType, fromTransportId(sourceId.key[2], fixedUpSourceId));
                    seedKey.connectorId === connectorId ? connectorKeys.push(seedKey) : otherKeys.push(seedKey);
                }
                ;
            }
            const type = dealiases.itemType(aliasId, seed.typeId);
            const properties = {};
            for (const [key, value] of Object.entries(seed.properties)) {
                // only add properties that are mapped in the schema
                if (dealiases.hasProperty(aliasId, seed.typeId, key)) {
                    const dealiasedPropertyName = dealiases.property(aliasId, seed.typeId, key);
                    if (dealiasedPropertyName) {
                        properties[dealiasedPropertyName] = value;
                    }
                }
            }
            entities.push(new SeedEntity(seed.seedId, connectorKeys, otherKeys, properties, seed.label, seed, type));
            // this.addSeedEntity(seed.seedId, seed.label, type, connectorKeys, otherKeys, seed, properties);
        }
    }
    return new Seeds(entities);
}
exports.createProductSeeds = createProductSeeds;
function createFrameworkSeeds(connectorId, rawSeeds, aliasId, dealiases) {
    const entities = [];
    if (rawSeeds) {
        for (const rawSeed of rawSeeds) {
            // for dealiased types
            const connectorKeys = [];
            const otherKeys = [];
            // for aliased type
            const connectorAliasedType = [];
            const otherAliasedTypes = [];
            for (const sourceId of rawSeed.ids) {
                const tokens = sourceId.id.split("::");
                const aliasedType = tokens[1];
                const transportId = tokens[0];
                const id = fromTransportId(transportId, aliasedType);
                const seedKey = new SeedKey(tokens[2], dealiases.itemType(aliasId, aliasedType), id, transportId);
                // Workaround for non LCS seeds that do not have ++type suffix
                // Basically add in dynamic property
                if (id === fromTransportId(id, aliasedType))
                    seedKey.connectorId === connectorId ? connectorKeys.push(seedKey) : otherKeys.push(seedKey);
                seedKey.connectorId === connectorId ? connectorAliasedType.push(aliasedType) : otherAliasedTypes.push(aliasedType);
            }
            const type = connectorKeys.length > 0 && connectorKeys[0].type || otherKeys.length > 0 && otherKeys[0].type || dealiases.itemType(aliasId, rawSeed.type);
            const aliasedType = connectorAliasedType.length > 0 && connectorAliasedType[0] || otherKeys.length > 0 && connectorAliasedType[0] || rawSeed.type;
            const properties = {};
            if (rawSeed.atts) {
                for (const attribute of rawSeed.atts) {
                    // only add properties that are mapped in the schema
                    if (dealiases.hasProperty(aliasId, aliasedType, attribute.id)) {
                        const dealiasedPropertyName = dealiases.property(aliasId, aliasedType, attribute.id);
                        if (dealiasedPropertyName) {
                            properties[dealiasedPropertyName] = attribute.val;
                        }
                    }
                    else if (dealiases.hasPropertyIgnoreSpaces(aliasId, aliasedType, attribute.id)) {
                        const dealiasedPropertyName = dealiases.propertyIgnoreSpaces(aliasId, aliasedType, attribute.id);
                        if (dealiasedPropertyName) {
                            properties[dealiasedPropertyName] = attribute.val;
                        }
                    }
                    else {
                        exports.LOGGER.debug(`No param found for attribute ${attribute.id}`);
                    }
                }
            }
            entities.push(new SeedEntity(rawSeed.ident, connectorKeys, otherKeys, properties, rawSeed.label, rawSeed, type));
        }
    }
    return new Seeds(entities);
}
exports.createFrameworkSeeds = createFrameworkSeeds;
class Properties {
    asAliasedProperties(aliasedIitemType) {
        exports.LOGGER.silly("asAliasedProperties()");
        const result = {};
        for (var prop in this) {
            if (Object.prototype.hasOwnProperty.call(this, prop)) {
                const aliasId = prop.split("::")[1]; // get the bit after ::
                const aliasValue = aliasedIitemType[aliasId];
                if (aliasValue) {
                    (result[aliasValue] = this[prop]);
                }
                else {
                    exports.LOGGER.verbose("Warning no alias for property " + prop);
                }
            }
        }
        return result;
    }
}
const transportIdSeparator = '++';
function transportIdSuffix(type) {
    const typeString = typeof type === 'string' ? type : type.typeId;
    return `${transportIdSeparator}${typeString}`;
}
function toTransportId(id, type) {
    return `${id}${transportIdSuffix(type)}`;
}
function fromTransportId(id, type) {
    // remove the suffix if it matches the type
    return id.endsWith(transportIdSuffix(type)) ? id.substring(0, id.length - transportIdSuffix(type).length) : id;
}
class SourceReference {
    constructor(id, name, type, locationUrl, imageUrl, description) {
        this._id = id;
        this._info = { name, type, image: imageUrl, location: locationUrl, description };
    }
    toProductSourceRefs() {
        if (!this._info) {
            return undefined;
        }
        return {
            id: this._id,
            source: this._info,
            userModifiable: false
        };
    }
}
class Entity {
    constructor(id, type, seed) {
        this.properties = new Properties();
        this._id = id;
        this._type = type;
        this._seed = seed;
    }
    get id() { return this._id; }
    ;
    get type() { return this._type; }
    get identity() { return this._identity; }
    get transportId() {
        return this._transportId;
    }
    set identity(value) {
        this._identity = value;
    }
    get seed() { return this._seed; }
    setSourceReference(id, name, type, locationUrl, imageUrl, description) {
        this._sourceReference = new SourceReference(id, name, type, locationUrl, imageUrl, description);
    }
    setProperty(propertyName, propertyValue) {
        this.properties[propertyName] = propertyValue;
    }
    setProperties(properties) {
        for (let [key, value] of Object.entries(properties)) {
            this.properties[key] = value;
        }
    }
    toAliasedNonSeedEntity(aliases, aliasId) {
        exports.LOGGER.silly("toAliasedNonSeedEntity");
        const aliasEntityType = aliases.itemType(aliasId, this.type);
        this._transportId = toTransportId(this.id, aliasEntityType.typeId);
        return {
            id: this._transportId,
            typeId: aliasEntityType.typeId,
            properties: this.properties.asAliasedProperties(aliasEntityType),
        };
    }
    toFrameworkEntity(aliases, aliasId) {
        exports.LOGGER.silly("toFrameworkEntity");
        if (this.seed) {
            if (this.seed.connectorKeys.length > 0) {
                // need to make it have a key that is already on the chart to ensure a match
                let typeId;
                if (typeof this.seed.connectorKeys[0].type !== 'string') {
                    const aliasEntityType = aliases.itemType(aliasId, this.seed.connectorKeys[0].type);
                    typeId = aliasEntityType.typeId;
                }
                else {
                    // it's just a string that couldn't be dealiased so return as is
                    typeId = this.seed.connectorKeys[0].type;
                }
                if (this.seed.connectorKeys[0].id === this.seed.connectorKeys[0].transportId) {
                    // this is not an LCS seed so don't convert the id
                    this._transportId = this.seed.connectorKeys[0].id;
                }
                else {
                    this._transportId = toTransportId(this.seed.connectorKeys[0].id, typeId);
                }
                return {
                    id: this._transportId,
                    typeId: typeId,
                    properties: {}
                };
            }
            else {
                const typeId = typeof this.seed.type !== 'string' ? this.seed.type.typeId : this.seed.type;
                this._transportId = this.id;
                return {
                    identity: this.identity,
                    id: this.id,
                    typeId: typeId ? typeId : this.seed.rawSeed.type,
                    properties: {}
                };
            }
        }
        else {
            const basicResult = this.toAliasedNonSeedEntity(aliases, aliasId);
            if (this.identity) {
                // 
                basicResult.identity = this.identity;
            }
            return basicResult;
        }
    }
    toProductEntity(aliases, aliasId) {
        var _a;
        exports.LOGGER.silly("toProductEntity");
        if (this.seed) {
            let properties = {};
            if (typeof this.seed.type === 'string') { // i.e. it's not aliased
                // so not really valid to add properties using alias as we don't know the type
                properties = this.seed.rawSeed.properties;
                // but want to warn if values have been added (may want to revisit)
                const addedProperties = this.properties.asAliasedProperties();
                if (Object.keys(addedProperties).length > 0) {
                    exports.LOGGER.warn("Not adding properties to entity which was added as seed as the type is not aliased");
                }
            }
            else {
                // here we know the type so it makes sense to add any new properties
                const aliasEntityType = aliases.itemType(aliasId, this.seed.type);
                properties = Object.assign(Object.assign({}, this.seed.rawSeed.properties), this.properties.asAliasedProperties(aliasEntityType));
            }
            this._transportId = this.id;
            return {
                id: this._transportId,
                typeId: this.seed.rawSeed.typeId,
                properties: properties
            };
        }
        else {
            if (this.type) {
                const result = this.toAliasedNonSeedEntity(aliases, aliasId);
                result["sourceReference"] = (_a = this._sourceReference) === null || _a === void 0 ? void 0 : _a.toProductSourceRefs();
                return result;
            }
            else {
                // this is the case where the entity is an InfoStore entity
                // id needs to be deserialized.
                return {
                    id: JSON.parse(this.id || "")
                };
            }
        }
    }
    toTestEntity() {
        exports.LOGGER.silly("toTestEntity");
        if (this.seed) {
            return {
                id: this.id,
                typeId: this.seed.rawSeed.typeId
            };
        }
        else {
            return {
                id: this.id,
                type: this.type,
                properties: this.properties
            };
        }
    }
}
exports.Entity = Entity;
class InfoStoreItem {
    constructor(id) {
        this._id = id;
    }
    toProductItem() {
        return {
            id: JSON.parse(this._id)
        };
    }
}
class Link {
    constructor(id, type, fromEnd, toEnd, linkDirection) {
        this.properties = new Properties();
        this._linkDirection = Direction.NONE;
        this._id = id;
        this._type = type;
        this._fromEnd = fromEnd;
        this._toEnd = toEnd;
        this._linkDirection = linkDirection;
    }
    get id() { return this._id; }
    ;
    get type() { return this._type; }
    get fromEnd() { return this._fromEnd; }
    get toEnd() { return this._toEnd; }
    get linkDirection() { return this._linkDirection; }
    set linkDirection(value) { this._linkDirection = value; }
    setSourceReference(id, name, type, locationUrl, imageUrl, description) {
        this._sourceReference = new SourceReference(id, name, type, locationUrl, imageUrl, description);
    }
    setProperty(propertyName, propertyValue) {
        this.properties[propertyName] = propertyValue;
    }
    setProperties(properties) {
        for (let [key, value] of Object.entries(properties)) {
            this.properties[key] = value;
        }
    }
    toAliasedLink(aliases, aliasId) {
        exports.LOGGER.silly("toAliasedLink");
        const basicAliasLinkType = aliases.itemType(aliasId, this.type);
        const fromEndType = this.fromEnd.seed ? this.fromEnd.seed.type : this.fromEnd.type;
        const toEndType = this.toEnd.seed ? this.toEnd.seed.type : this.toEnd.type;
        let overrideLinkType = aliases.overrideLinkType(basicAliasLinkType, fromEndType, toEndType)
            || aliases.overrideLinkType(basicAliasLinkType, toEndType, fromEndType)
            || basicAliasLinkType;
        // if these are InfoStore entities, they won't have transportIds
        // and need to parse id to get id object.
        const fromEndId = this.fromEnd.transportId || JSON.parse(this.fromEnd.id || "");
        const toEndId = this.toEnd.transportId || JSON.parse(this.toEnd.id || "");
        return {
            id: toTransportId(this.id, overrideLinkType),
            typeId: overrideLinkType.typeId,
            linkDirection: this.linkDirection,
            fromEndId,
            toEndId,
            properties: this.properties.asAliasedProperties(overrideLinkType),
        };
    }
    toFrameworkLink(aliases, aliasId) {
        exports.LOGGER.silly("toFrameworkLink");
        const result = this.toAliasedLink(aliases, aliasId);
        renameProperty(result, "fromEndId", "end1Id");
        renameProperty(result, "toEndId", "end2Id");
        return result;
    }
    toProductLink(aliases, aliasId) {
        var _a;
        exports.LOGGER.silly("toProductLink");
        const result = this.toAliasedLink(aliases, aliasId);
        result["sourceReference"] = (_a = this._sourceReference) === null || _a === void 0 ? void 0 : _a.toProductSourceRefs();
        return result;
    }
    toTestLink() {
        exports.LOGGER.silly("toTestLink");
        return {
            id: this.id,
            type: this.type,
            linkDirection: this.linkDirection,
            fromEndId: this.fromEnd.id,
            toEndId: this.toEnd.id,
            properties: this.properties,
        };
    }
}
exports.Link = Link;
class Result {
    constructor() {
        this.entityMap = new Map();
        this.linkMap = new Map();
        this.infoStoreLinkMap = new Map();
    }
    addInfoStoreEntity(recordId) {
        const id = JSON.stringify({ infoStoreRecordId: recordId });
        let entity = this.entityMap.get(id);
        if (!entity) {
            entity = new Entity(id, undefined, undefined);
            this.entityMap.set(id, entity);
        }
        return entity;
    }
    addInfoStoreLink(recordId) {
        const id = JSON.stringify({ infoStoreRecordId: recordId });
        if (!this.infoStoreLinkMap.get(id)) {
            this.infoStoreLinkMap.set(id, new InfoStoreItem(id));
        }
    }
    addLink(id, type, fromEnd, toEnd) {
        const transportId = toTransportId(id, type);
        let link = this.linkMap.get(transportId);
        if (link) {
            return link;
        }
        else {
            link = new Link(id, type, fromEnd, toEnd, Direction.NONE);
            this.linkMap.set(transportId, link);
            return link;
        }
    }
    addEntity(id, type) {
        const transportId = toTransportId(id, type);
        let entity = this.entityMap.get(transportId);
        if (entity) {
            return entity;
        }
        else {
            entity = new Entity(id, type, undefined);
            this.entityMap.set(transportId, entity);
            return entity;
        }
    }
    addEntityFromSeed(seed) {
        const id = seed.identity;
        // const id = seed.rawSeed.seedId || seed.rawSeed.ident.split("\\")[1];
        let entity = this.entityMap.get(id);
        if (entity) {
            return entity;
        }
        else {
            entity = new Entity(id, undefined, seed);
            this.entityMap.set(id, entity);
            return entity;
        }
    }
    toFrameworkResult(connectorId, aliases, aliasId) {
        const statusMessage = this.statusMessage ? this.statusMessage : (this.entityMap.size == 0
            ? "No results found." : `${this.entityMap.size} entity(s) and ${this.linkMap.size} link(s) returned.`);
        return {
            recommendedChartingSchemeId: getChartingSchemeId(connectorId, aliasId),
            status: this.status || "OK",
            statusMessage: statusMessage,
            entities: Array.from(this.entityMap.values()).map(entity => entity.toFrameworkEntity(aliases, aliasId)),
            links: Array.from(this.linkMap.values()).map(link => link.toFrameworkLink(aliases, aliasId))
        };
    }
    toProducctResult(aliases, aliasId) {
        const entities = Array.from(this.entityMap.values()).map(entity => entity.toProductEntity(aliases, aliasId));
        const links = Array.from(this.linkMap.values()).map(link => link.toProductLink(aliases, aliasId));
        Array.from(this.infoStoreLinkMap.values()).forEach((x) => links.push(x.toProductItem()));
        return {
            errorMessage: this.statusMessage,
            entities,
            links
        };
    }
    toTestResult() {
        return {
            status: this.status,
            statusMessage: this.statusMessage,
            entities: Array.from(this.entityMap.values()).map(entity => entity.toTestEntity()),
            links: Array.from(this.linkMap.values()).map(link => link.toTestLink())
        };
    }
}
exports.Result = Result;
function getChartingSchemeId(connectorId, aliasId) {
    return `loopback-connector-server::${connectorId}::${aliasId}`;
}
class SimpleSeedConstraints {
    constructor(metadata) {
        this._metadata = metadata;
    }
    get isSimpleSeedConstraints() { return true; }
    get connectorId() { return this._connectorId; }
    set connectorId(value) { this._connectorId = value; }
    get metadata() { return this._metadata; }
    asProductSeedsConstraints(aliases, aliasId) {
        const result = {
            seedTypes: {
                allowedTypes: AllowedTypes.ENTITY,
                itemTypes: this._metadata.types.map(type => {
                    return { id: aliases.item(aliasId, type.typeId) };
                }),
            },
            min: this._metadata.min,
            max: this._metadata.max
        };
        if (this._metadata.thisConnectorOnly) {
            result.connectorIds = [this.connectorId];
        }
        return result;
    }
}
class FullSeedConstraints {
    constructor(metadata) {
        this._metadata = metadata;
    }
    get isSimpleSeedConstraints() { return false; }
    get metadata() { return this._metadata; }
    asProductSeedsConstraints(aliases, aliasId) {
        return {
            seedTypes: !this.metadata.seedTypes ? undefined : {
                allowedTypes: this.metadata.seedTypes.allowedTypes,
                itemTypes: this.metadata.seedTypes && this.metadata.seedTypes.itemTypes
                    && this.metadata.seedTypes.itemTypes.map(itemType => {
                        return { id: aliases.item(aliasId, itemType.id.typeId),
                            min: itemType.min,
                            max: itemType.max };
                    })
            },
            min: this.metadata.min,
            max: this.metadata.max,
            connectorIds: this.metadata.connectorIds,
        };
    }
}
exports.configMap = new Map();
let services = [];
let conditions = [];
let seedConstraints;
let includeJWT = false;
let includeAsyncState = false;
class Config {
    constructor(metadata, services, id) {
        this.metadata = metadata;
        this.services = services;
        this.id = id;
    }
    getService(id) {
        return this.services.find(service => service.id === id);
    }
    createAttributeMappings(itemTypeProperty, itemType) {
        const result = [];
        for (const property in itemType) {
            if (property !== "typeId") {
                result.push({
                    attributeId: `${itemType[property]}`,
                    propertyId: itemType[property],
                    defaultValue: ""
                });
            }
        }
        return result;
    }
    createAttributes(alias) {
        const result = [];
        for (const itemTypeProperty in alias) {
            if (itemTypeProperty !== "DefaultEntity" && itemTypeProperty !== "DefaultLink") {
                const typeAlias = alias[itemTypeProperty];
                for (const property in typeAlias) {
                    result.push({
                        id: `${typeAlias[property]}`,
                        name: property,
                        type: "text",
                        show: true,
                        prefix: "",
                        suffix: ""
                    });
                }
            }
        }
        return result;
    }
    createItemMappings(alias) {
        const result = [];
        for (const itemTypeProperty in alias) {
            if (itemTypeProperty !== "DefaultEntity" && itemTypeProperty !== "DefaultLink") {
                const typeAlias = alias[itemTypeProperty];
                // Use the first (non typeId) property as the label if it exists or use the typeId as the default value
                const labelPropertyId = Object.keys(typeAlias).length > 1 ? Object.keys(typeAlias)[1] : null;
                result.push({
                    typeId: alias[itemTypeProperty].typeId,
                    propertyMappings: [
                        { name: "label", propertyId: labelPropertyId, defaultValue: typeAlias.typeId }
                    ],
                    attributeMappings: this.createAttributeMappings(itemTypeProperty, typeAlias)
                });
            }
        }
        return result;
    }
    createChartingSchemes(alias, aliasId) {
        return [
            {
                id: getChartingSchemeId(this.id, aliasId),
                version: "1.0",
                name: "Generated Charting Scheme",
                format: "tc",
                defaultEntityIcon: "cirwhite",
                defaultLinkColor: "#000000",
                entityMappings: this.createItemMappings(alias),
                linkMappings: this.createItemMappings(alias),
                attributes: this.createAttributes(alias)
            }
        ];
    }
    asFrameworkConnector(aliases, aliasId, schema) {
        var _a, _b;
        return {
            id: this.id,
            name: this.metadata.name || this.id,
            description: this.metadata.description || "",
            version: "1.3",
            services: this.services.map(service => service.asFrameworkService(this.id, aliasId)),
            searchForms: this.services.map(service => service.asFrameworkForm()),
            defaultValues: {
                timeZoneId: this.metadata.defaultTimeZoneId || "Europe/London",
                entityTypeId: aliases.item(aliasId, ((_a = this.metadata.defaultEntityType) === null || _a === void 0 ? void 0 : _a.typeId) || schema.DefaultEntity.typeId),
                linkTypeId: aliases.item(aliasId, ((_b = this.metadata.defaultLinkType) === null || _b === void 0 ? void 0 : _b.typeId) || schema.DefaultLink.typeId),
                linkDirection: "NONE"
            },
            // typeCatalog: {}, // Never actually used so ignoring
            chartingSchemes: this.createChartingSchemes(aliases.alias(aliasId), aliasId)
        };
    }
    asProductConnector(aliases, aliasId, schema, allowCustom) {
        var _a, _b, _c;
        let schemaUrl = undefined;
        let chartingSchemesUrl = undefined;
        if (aliases.alias(aliasId)["Files"]) {
            const root = `/${this.id}/product/${aliasId}`;
            schemaUrl = `${root}/schema`;
            chartingSchemesUrl = `${root}/chartingSchemes`;
        }
        return {
            schemaUrl,
            chartingSchemesUrl,
            schemaShortName: (_a = aliases.alias(aliasId)) === null || _a === void 0 ? void 0 : _a.SchemaShortName,
            services: this.services.map(service => service.asProductService(this.id, aliases, aliasId, allowCustom)),
            clientConfigs: this.services.map(service => service.asProductClientConfig(allowCustom)).filter(x => x),
            defaultValues: {
                timeZoneId: "Europe/London",
                entityTypeId: aliases.item(aliasId, ((_b = this.metadata.defaultEntityType) === null || _b === void 0 ? void 0 : _b.typeId) || schema.DefaultEntity.typeId),
                linkTypeId: aliases.item(aliasId, ((_c = this.metadata.defaultLinkType) === null || _c === void 0 ? void 0 : _c.typeId) || schema.DefaultLink.typeId),
                linkDirection: "NONE",
                resultIdsPersistent: true // allows ids to be pulled out of seeds
            }
        };
    }
}
exports.Config = Config;
class Service {
    constructor(metadata, id, conditions, seedConstraints, includeJWT, includeAsyncState) {
        this.metadata = metadata;
        this.id = id;
        this.conditions = conditions || [];
        this.seedConstraints = seedConstraints;
        this.includeJWT = includeJWT;
        this.includeAsyncState = includeAsyncState;
    }
    includesJWT() {
        return this.includeJWT;
    }
    includesAsyncState() {
        return this.includeAsyncState;
    }
    takesSeeds() {
        return this.seedConstraints !== undefined;
    }
    convertConditionsToParams(incomingConditions) {
        return this.conditions.map(condition => {
            const param = incomingConditions.find(x => x.id === "" + condition.parameterIndex);
            if (!param) { // wasn't passed through as value
                return undefined;
            }
            else {
                if (condition.metadata.logicalType === 'INTEGER') {
                    return parseInt(param.value, 10);
                }
                // [TODO] - see if we need any more special treatment here
                else {
                    // pass through as whatever it came in as
                    return param.value;
                }
            }
        }).reverse();
    }
    isRequiredCustomForm() {
        // Contains External_URL
        const prefix = `Service: '${this.metadata.name}' contains`;
        const postfix = `It will have a form type CUSTOM, making it unavailable in External Searches UI.`;
        if (this.conditions.find(x => x.metadata.logicalType === LogicalType.EXTERNAL_URL)) {
            exports.LOGGER.warn(`${prefix} EXTERNAL_URL condition. ${postfix}`);
            return true;
        }
        return false;
    }
    isIgnorableCustomForm() {
        const prefix = `Service: '${this.metadata.name}' contains ignorable properties`;
        const postfix = `This will be ignored in product mode but available in custom mode .`;
        // Contains MultiValue select
        if (this.conditions.find(x => x.metadata.logicalType === LogicalType.SELECTED_FROM && x.metadata.isMultiSelect)) {
            exports.LOGGER.warn(`${prefix} multi select SELECTED_FROM condition. ${postfix}`);
            return true;
        }
        // Contains defaultValue 
        if (this.conditions.find((x) => x.metadata.defaultValue)) {
            exports.LOGGER.warn(`${prefix} defaultValue in condition. ${postfix}.`);
            return true;
        }
        return false;
    }
    identifyCustomStatus() {
        this.customConditionsStatus = this.isRequiredCustomForm() ? "REQUIRED"
            : this.isIgnorableCustomForm() ? "IGNORABLE"
                : "NO_CUSTOM";
    }
    asFrameworkService(configId, aliasId) {
        return {
            id: this.id,
            name: this.metadata.name || this.id,
            description: this.metadata.description || this.metadata.name || "",
            searchFormId: this.id,
            iconUrl: this.metadata.iconUrl,
            mergeBehavior: this.metadata.mergeBehavior,
            url: `/${configId}/framework/${aliasId}/${this.id}`
        };
    }
    asProductService(configId, aliases, aliasId, allowCustom) {
        const productConstraints = this.seedConstraints ?
            this.seedConstraints.asProductSeedsConstraints(aliases, aliasId) : undefined;
        const clientConfigType = this.conditions.length === 0 ? "NONE"
            : this.customConditionsStatus === "NO_CUSTOM" ? "FORM"
                : this.customConditionsStatus === "REQUIRED" ? "CUSTOM"
                    : this.customConditionsStatus === "IGNORABLE" && allowCustom ? "CUSTOM"
                        : "FORM";
        const url = `/${configId}/product/${aliasId}/${this.id}`;
        return {
            id: this.id,
            name: this.metadata.name || this.id,
            description: this.metadata.description || this.metadata.name || "",
            clientConfigId: this.conditions.length === 0 ? undefined : this.id,
            clientConfigType,
            acquireUrl: this.metadata.async ? undefined : url,
            seedConstraints: productConstraints,
            async: this.metadata.async ? { queriesResource: url } : undefined // set if async
        };
    }
    asFrameworkForm() {
        return {
            id: this.id,
            sections: [{
                    title: "",
                    conditions: this.conditions.map(condition => condition.asFrameworkCondition()).reverse()
                }]
        };
    }
    asProductClientConfig(allowCustom) {
        if (!this.conditions || this.conditions.length === 0) {
            return undefined;
        }
        return {
            id: this.id,
            config: {
                sections: [{
                        title: "",
                        conditions: this.conditions.map(condition => condition.asProductCondition(allowCustom)).reverse()
                    }]
            }
        };
    }
}
exports.Service = Service;
class Condition {
    constructor(metadata, parameterIndex) {
        this.metadata = metadata;
        this.parameterIndex = parameterIndex;
    }
    asBaseCondition() {
        const asNumber = this.metadata;
        return {
            id: "" + this.parameterIndex,
            label: this.metadata.label || "" + this.parameterIndex,
            description: this.metadata.description || "",
            logicalType: this.metadata.logicalType,
            minValue: asNumber ? asNumber.minValue : undefined,
            maxValue: asNumber ? asNumber.maxValue : undefined,
            externalUrlRef: this.metadata.logicalType === LogicalType.EXTERNAL_URL ? this.metadata.externalUrlRef : undefined
        };
    }
    asFrameworkCondition() {
        const result = this.asBaseCondition();
        result.isMandatory = this.metadata.mandatory;
        result.defaultValue = this.metadata.defaultValue ? this.metadata.defaultValue : undefined;
        result.isMultiSelect = this.metadata.logicalType === LogicalType.SELECTED_FROM ? this.metadata.isMultiSelect : undefined;
        const asString = this.metadata;
        if (asString && asString.validation) {
            result.additionalStringValidation = {
                validationType: "isRegEx",
                validationOptions: asString.validation.regex,
                message: asString.validation.message
            };
        }
        const asList = this.metadata;
        if (asList && asList.possibleValues) {
            result.possibleValues = asList.possibleValues ? asList.possibleValues.map(x => { return { displayValue: x.displayName, value: x.value }; }) : [];
        }
        return result;
    }
    asProductCondition(allowCustom) {
        const result = this.asBaseCondition();
        result.mandatory = this.metadata.mandatory;
        const asString = this.metadata;
        result.extraStringValidation = asString && asString.validation ? {
            regex: asString.validation.regex,
            message: asString.validation.message
        } : undefined;
        const asList = this.metadata;
        if (asList && asList.possibleValues) {
            result.possibleValues = asList.possibleValues;
        }
        // Add on options available if clientConfigType is CUSTOM
        if (allowCustom) {
            const asSelect = this.metadata;
            if (asSelect && asSelect.isMultiSelect) {
                result.isMultiSelect = asSelect.isMultiSelect;
            }
            const asAny = this.metadata;
            if (asAny.defaultValue) {
                result.defaultValue = asAny.defaultValue;
            }
        }
        return result;
    }
}
function connector(metadata) {
    return function (constructor) {
        exports.configMap.set(constructor["name"], new Config(metadata, services, constructor["name"]));
        // Do some logging
        exports.LOGGER.info(`Added connector: '${metadata.name || constructor["name"]}'`);
        for (const service of services) {
            const serviceParams = service.conditions.map(x => "'" + (x.metadata.label || x.parameterIndex) + "'").reverse();
            if (service.takesSeeds()) {
                serviceParams.push("'seeds'");
                if (service.seedConstraints) {
                    if (service.seedConstraints.isSimpleSeedConstraints) {
                        service.seedConstraints.connectorId = constructor["name"];
                    }
                }
            }
            if (service.includesJWT()) {
                serviceParams.push("'jwt'");
            }
            exports.LOGGER.info(`\tAdded service: '${service.metadata.name || service.includeJWT}' (${serviceParams.join(", ")})`);
            service.identifyCustomStatus();
        }
        // reset services array
        services = [];
        // LOGGER.info("Created Connector " + constructor["name"]);
    };
}
exports.connector = connector;
function service(metadata) {
    return function (target, propertyKey, descriptor) {
        services.push(new Service(metadata, propertyKey, conditions, seedConstraints, includeJWT, includeAsyncState));
        // reset current conditions array
        conditions = [];
        seedConstraints = undefined;
        includeJWT = false;
        includeAsyncState = false;
        // LOGGER.info(`Created Service: ${metadata.name || propertyKey}`);
    };
}
exports.service = service;
function condition(metadata) {
    return function (target, propertyKey, parameterIndex) {
        conditions.push(new Condition(metadata, parameterIndex));
        // LOGGER.verbose("Created Condition: " + metadata.label || "" + parameterIndex);
    };
}
exports.condition = condition;
function jwt() {
    // currently value is  not used but is required to make the function permissable as a decorator.
    return function (target, propertyKey, parameterIndex) {
        includeJWT = true;
    };
}
exports.jwt = jwt;
function asyncState() {
    // currently value is  not used but is required to make the function permissable as a decorator.
    return function (target, propertyKey, parameterIndex) {
        includeAsyncState = true;
    };
}
exports.asyncState = asyncState;
function seeds(metadata) {
    return function (target, propertyKey, parameterIndex) {
        if (metadata["types"]) {
            seedConstraints = new SimpleSeedConstraints(metadata);
        }
        else {
            seedConstraints = new FullSeedConstraints(metadata);
        }
    };
}
exports.seeds = seeds;
class DeAliases {
    constructor(aliasesObj, schema) {
        this.itemDeAliasMap = new Map();
        this.propertyDeAliasMap = new Map();
        exports.LOGGER.silly("DeAliases.constructor");
        this.aliasesObj = aliasesObj;
        const aliases = aliasesObj.aliases;
        for (let aliasKey in aliases) {
            if (aliases.hasOwnProperty(aliasKey)) {
                const alias = aliases[aliasKey];
                this.propertyDeAliasMap.set(aliasKey, new Map());
                this.itemDeAliasMap.set(aliasKey, new Map());
                for (let itemKey in alias) {
                    if (alias.hasOwnProperty(itemKey) && itemKey !== "DefaultEntity" && itemKey !== "DefaultLink") {
                        const item = alias[itemKey];
                        const itemDeAlias = this.itemDeAliasMap.get(aliasKey);
                        if (itemDeAlias) {
                            itemDeAlias.set(item.typeId, schema[itemKey]);
                        }
                        const itemPropertyMap = new Map();
                        const propertyDeAlias = this.propertyDeAliasMap.get(aliasKey);
                        if (propertyDeAlias) {
                            propertyDeAlias.set(item["typeId"], itemPropertyMap);
                        }
                        for (let itemProperty in item) {
                            if (item.hasOwnProperty(itemProperty)) {
                                if (itemProperty === "typeId") {
                                    itemPropertyMap.set(item[itemProperty], itemKey);
                                }
                                else {
                                    itemPropertyMap.set(item[itemProperty], itemKey + "::" + itemProperty);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    // It looks like there is a bug in the product whereby the 
    // SchemaShortName is used to prefix the types from connector/gateway schemas.
    // Trying to make this work both ways so if it doesn't find the type, it will
    // check to see if it has the type with -SchemaShortName prefix.
    // NB, there will still be problems if items from the IS schema are used as they
    // currently come through wihout a prefix
    withoutShortnameSuffixIfPresent(aliasesId, itemAliasId) {
        var _a;
        const separator = "-";
        const tokens = itemAliasId.split(separator);
        if (tokens.length > 1 && this.aliasesObj.alias(aliasesId).SchemaShortName) {
            const suffix = (_a = tokens.pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase(); // looks like it's already always lc but anyway ...
            const schemaShortName = this.aliasesObj.alias(aliasesId).SchemaShortName;
            if (schemaShortName.toLowerCase() === suffix) { // looks like always gets lower cased by product
                return tokens.join(separator);
            }
        }
        return itemAliasId;
    }
    itemType(aliasesId, itemAliasId) {
        exports.LOGGER.silly("DeAliases.itemType");
        const itemDeAlias = this.itemDeAliasMap.get(aliasesId);
        if (itemDeAlias) {
            const result = itemDeAlias.get(itemAliasId);
            if (result) {
                return result;
            }
        }
        exports.LOGGER.debug(`Not got an item alias - alias: ${aliasesId}, itemAlias: ${itemAliasId}. Defaulting to ${itemAliasId}`);
        return itemAliasId;
    }
    hasProperty(aliasesId, itemAliasId, propertyAliasId) {
        exports.LOGGER.silly("DeAliases.hasProperty");
        const propertyDeAliasMap = this.propertyDeAliasMap.get(aliasesId);
        if (propertyDeAliasMap) {
            const itemDeAliasMap = propertyDeAliasMap.get(itemAliasId);
            if (itemDeAliasMap) {
                const result = itemDeAliasMap.get(propertyAliasId);
                if (result) {
                    return true;
                }
            }
        }
        return false;
    }
    // added this because for framework, attribute ids are added without spaces so want to also search
    // where name without spaces matches
    hasPropertyIgnoreSpaces(aliasesId, itemAliasId, propertyAliasId) {
        exports.LOGGER.silly("DeAliases.hasPropertyIgnoreSpaces");
        const propertyDeAliasMap = this.propertyDeAliasMap.get(aliasesId);
        if (propertyDeAliasMap) {
            const itemDeAliasMap = propertyDeAliasMap.get(itemAliasId);
            if (itemDeAliasMap) {
                for (const value of itemDeAliasMap.keys()) {
                    if (value.replace(/ /g, '') === propertyAliasId) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    property(aliasesId, itemAliasId, propertyAliasId) {
        exports.LOGGER.silly("DeAliases.property");
        // return this.propertyDeAliasMap.get(aliasesId).get(itemAliasId).get(propertyAliasId);
        const propertyDeAliasMap = this.propertyDeAliasMap.get(aliasesId);
        if (propertyDeAliasMap) {
            const itemDeAliasMap = propertyDeAliasMap.get(itemAliasId);
            if (itemDeAliasMap) {
                const result = itemDeAliasMap.get(propertyAliasId);
                if (result) {
                    return result;
                }
            }
        }
        throw `Not valid alias ${aliasesId} or item alias ${propertyAliasId}`;
    }
    // added this because for framework, attribute ids are added without spaces so want to also search
    // where name without spaces matches
    propertyIgnoreSpaces(aliasesId, itemAliasId, propertyAliasId) {
        exports.LOGGER.silly("DeAliases.property");
        // return this.propertyDeAliasMap.get(aliasesId).get(itemAliasId).get(propertyAliasId);
        const propertyDeAliasMap = this.propertyDeAliasMap.get(aliasesId);
        if (propertyDeAliasMap) {
            const itemDeAliasMap = propertyDeAliasMap.get(itemAliasId);
            if (itemDeAliasMap) {
                for (const value of itemDeAliasMap.keys()) {
                    if (value.replace(/ /g, '') === propertyAliasId) {
                        return itemDeAliasMap.get(value);
                    }
                }
            }
        }
        throw `Not valid alias ${aliasesId} or item alias ${propertyAliasId}`;
    }
}
exports.DeAliases = DeAliases;
class Aliases {
    constructor(aliases) {
        this.aliases = aliases || {};
        // store the original alias ids
        this.aliasesIds = Object.keys(aliases);
    }
    hasAlias(aliasesId) {
        return this.aliasesIds.includes(aliasesId);
    }
    alias(aliasesId) {
        exports.LOGGER.silly("Aliases.alias");
        let alias = this.aliases[aliasesId];
        if (!alias) {
            this.aliases[aliasesId] = {};
            alias = this.aliases[aliasesId];
        }
        return alias;
    }
    itemAlias(aliasesId, itemAliasId) {
        exports.LOGGER.silly("Aliases.itemAlias");
        const alias = this.alias(aliasesId);
        let itemAlias = alias[itemAliasId];
        if (!itemAlias) {
            alias[itemAliasId] = {};
            itemAlias = alias[itemAliasId];
        }
        return itemAlias;
    }
    itemType(aliasesId, itemType) {
        exports.LOGGER.silly("Aliases.itemType");
        if (typeof itemType === 'string') {
            throw `Trying to get an itemType based on a string ${itemType}. This is currently not permitted.`;
        }
        return this.itemAlias(aliasesId, itemType.typeId);
    }
    overrideLinkType(linkType, fromEndType, toEndType) {
        exports.LOGGER.silly("Aliases.overrideLinkType");
        let result;
        if (linkType.overrides) {
            for (const overrideLinkType of linkType.overrides) {
                if (overrideLinkType.fromType === fromEndType
                    && overrideLinkType.toType === toEndType) {
                    result = overrideLinkType;
                }
            }
        }
        return result;
    }
    item(aliasesId, itemAliasId) {
        exports.LOGGER.silly("Aliases.item");
        return this.itemAlias(aliasesId, itemAliasId)["typeId"];
    }
    entityProperty(aliasesId, alias) {
        exports.LOGGER.silly("Aliases.entityProperty");
        const tokens = alias.split("::");
        return this.itemAlias(aliasesId, tokens[0])[tokens[1]];
    }
}
exports.Aliases = Aliases;
function renameProperty(obj, oldName, newName) {
    obj[newName] = obj[oldName];
    delete obj[oldName];
}
// Used to ensure that the proxy always returns the same proxy handler for a given alias and field
const itemProxyMap = new Map();
exports.aliasProxyHandler = {
    get(itemTarget, itemProp) {
        var _a;
        if (itemProp === "toJSON") {
            return `schema.${itemProp}`;
        }
        if (!itemProxyMap.has(itemTarget)) {
            itemProxyMap.set(itemTarget, new Map());
        }
        const itemProxy = itemProxyMap.get(itemTarget);
        if (itemProxy && !itemProxy.has(itemProp)) {
            itemProxy.set(itemProp, new Proxy({}, {
                get(fieldTarget, fieldProp) {
                    if (fieldProp === "typeId") {
                        return itemProp;
                    }
                    if (fieldProp === 'toJSON') {
                        return `schema.${itemProp}.${fieldProp}`;
                    }
                    else {
                        return itemProp + "::" + fieldProp;
                    }
                }
            }));
        }
        return ((_a = itemProxy) === null || _a === void 0 ? void 0 : _a.get(itemProp)) || "";
    }
};
//# sourceMappingURL=index.js.map