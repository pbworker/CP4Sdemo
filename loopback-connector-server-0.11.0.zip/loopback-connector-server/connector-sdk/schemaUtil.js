"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const systemEntityTypes = ["Set", "User", "Analysis Repository Chart", "Alert Feed", "Query", "Analyst's Notebook Chart"];
const schema = "/Users/stephenhasler/dev/i2ConnectorServer/CyberSchema/Cyber_v04.xml";
const outputSource = "/Users/stephenhasler/dev/i2ConnectorServer/loopback-connector-server/loopback-connector-server/build/template/SampleConnectors/uk-parliament/schema.ts";
let content = "";
console.log("Should be parsing schema " + schema);
var parseString = require('xml2js').parseString;
var xml = fs_1.default.readFileSync(schema);
parseString(xml, function (err, result) {
    var _a, _b;
    if (err) {
        console.log(err);
    }
    const entities = result['ns2:Schema'].ItemTypes[0].EntityTypes[0].EntityType;
    // console.log(entities);
    content = content + "import {} from ''\n\n";
    content = content + "export const theSchema = {\n";
    for (const entityType of entities) {
        const typeId = entityType["$"].Id;
        const typeName = entityType["$"].DisplayName;
        const typeNameProperty = typeName.replace(/ /g, '');
        const propertyGroupTypes = entityType.PropertyGroupTypes[0];
        const propertyTypes = entityType.PropertyTypes[0];
        if (!systemEntityTypes.includes(typeName)) {
            content = content + `${typeNameProperty}: {\n\ttypeId: "${typeId}", \n\tdisplayName: "${typeName}",\n`;
            if ((_a = propertyGroupTypes) === null || _a === void 0 ? void 0 : _a.PropertyGroupType) {
                for (const propertyGroupType of (_b = propertyGroupTypes) === null || _b === void 0 ? void 0 : _b.PropertyGroupType) {
                    if (propertyGroupType.PropertyTypes) {
                        for (const propertyTypes of propertyGroupType.PropertyTypes) {
                            console.log(propertyTypes);
                            for (const propertyType of propertyTypes.PropertyType || []) {
                                const propertyName = propertyType["$"].DisplayName;
                                const propertyNameProperty = propertyName.replace(/ /g, '');
                                const propertyId = propertyType["$"].Id;
                                const logicalType = propertyType["$"].LogicalType;
                                const p = `\t${propertyNameProperty}: {propertyId: "${propertyId}", displayName: "${propertyName}", logicalType: "${logicalType}"},\n`;
                                console.log("XXXX " + p);
                                content = content + p;
                            }
                        }
                    }
                }
            }
            content = content + `},\n`;
        }
    }
    content = content + "}";
    fs_1.default.writeFileSync(outputSource, content, { encoding: 'utf8', flag: 'w' });
});
//# sourceMappingURL=schemaUtil.js.map