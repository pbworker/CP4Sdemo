Link (in dev) or copy (in production) connector folders into this folder.
