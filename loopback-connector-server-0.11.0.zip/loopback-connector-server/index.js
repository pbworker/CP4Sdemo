const application = require('./dist');
const fs = require('fs');
const appConfig = require('config');

module.exports = application;

if (require.main === module) {
  // Run the application

  // Pull back the config from default.json/production.json (if in production mode)
  const config = appConfig.util.toObject();

  application.main(config).catch(err => {
    console.error('Cannot start the application.', err);
    process.exit(1);
  });
}
