import {
    BaseSchema, connector, service, condition, seeds, jwt, SeedEntity, Entity,
    Aliases, AliasedConnector, Result, Seeds, LogicalType, Status, LOGGER
  } from 'connector-sdk';
  import * as config from './connector.conf.json';
  import { aliases, schema } from './connector.aliases';
  const axios = require('axios');
  
  /**
   * UK Parliament Connector class
   */
  @connector({
    name: "UK Parliament",
    description: "Simple searching of UK Parliament data"
  })
  export class UKParliament implements AliasedConnector {
  
    // Private variable go  here:
    private axiosConfig = { headers: {"content-type": "application/json"} };

    
    // Private methods go here:

    private addLinkedCommitteeToResult(result: Result, personEntity: Entity, response: any) : void {
      const data = response.data;
      const memberArray = this.forceArray(data, "Members", "Member");
  
      for (const member of memberArray) {
        
        const committeesArray = this.forceArray(member, "Committees", "Committee");
        for (const committee of committeesArray) {
          
          // Create the Committee entity and add properties
          const committeeEntity = result.addEntity(committee["@Id"], schema.Committee);
          committeeEntity.setProperty(schema.Committee.Name, committee.Name);
          // Create the Member of Link to the current person and add properties:
          const linkId = personEntity.id + '_' + committee["@Id"];
          const link = result.addLink(linkId, schema.MemberOf, personEntity, committeeEntity);
          link.setProperty(schema.MemberOf.From, committee.StartDate.substring(0, 10));
          if (typeof committee.EndDate !== 'object') {
            link.setProperty(schema.MemberOf.To, committee.EndDate.substring(0, 10));
          }
  
        };    
      }
    }

   /*
    *  The data is not returned in the same way if there is a single item vs if there are multiple vs no data.
    *  This method simplifies the process of guaranteeing that an array is available.
    */
    private forceArray(root: any, firstLevel: string, secondLevel: string): any[] {
      let result = [];
      if (root && root[firstLevel]) {
        if (Array.isArray(root[firstLevel][secondLevel])) {
          result = root[firstLevel][secondLevel];
        } else {
          result.push(root[firstLevel][secondLevel])
        }
      }
      return result;
    }
  
    // Boiler-plate as implements AliasedConnector
    getAliases() {
      return new Aliases(aliases);
    }
  
    // Boiler-plate as implements AliasedConnector
    getSchema(): BaseSchema {
      return schema;
    }
  
    // Boiler-plate to return connector deployment folder
    getDir() {
      return __dirname;
    }

    // Service methods go here

    /*
     * Searches for People by either First Name, Surname or both.
     */
    @service({ name: "Find Members", description: "Simple search to find UK MPs" })
    async findMembers(
      @condition({
        label: "First Name",
        description: "Searches for MPs with this First Name",
        logicalType: LogicalType.SINGLE_LINE_STRING
      }) firstName: string,
      @condition({
        label: "Surname",
        description: "Searches for MPs with this Surname",
        logicalType: LogicalType.SINGLE_LINE_STRING
      }) surname: string
    ) {
  
      // Just log the various conditions
      console.log("First Name: " + firstName);
      console.log("Surname: " + surname);
  
      const result = new Result();

      if (!firstName && !surname) 
      {
        result.status = Status.Error;
        result.statusMessage = "You must enter at least one of First Name or Surname.";
        return result;
      }
  
      let query = "";
      if (firstName) {
        query = query + `forename=${firstName}|`;
      }
  
      if (surname) {
        query = query + `surname=${surname}`;
      }

      const url = `${config.queryUrlRoot}/${query}/BasicDetails`;

      const response = await axios.get(url, this.axiosConfig);
    
      const data = response.data;
      console.log(JSON.stringify(data, null, 2));

      const memberArray = this.forceArray(data, "Members", "Member");

      for (const member of memberArray) {
        // Create an entity for each member returned
        const entity = result.addEntity(member["@Member_Id"], schema.Person);
        
        entity.setProperty(schema.Person.FullName, member.DisplayAs);
        
        if (typeof member.DateOfBirth !== 'object') {
          entity.setProperty(schema.Person.DateOfBirth, member.DateOfBirth.substring(0, 10));
        }
        
        entity.setProperty(schema.Person.FirstName, member.BasicDetails.GivenForename);
        entity.setProperty(schema.Person.Surname, member.BasicDetails.GivenSurname);
      
      }

      return result;
    }
  
  /*
   * A service that takes a single Person seed and finds the committees they are on
   */
  @service({ name: "Basic Find Committees" })
  async findCommittees(
    @seeds(
      {
        types: [schema.Person],
        min: 1,
        max: 1,
      }
    ) seeds: Seeds
  ) {

    console.log("Got seeds " + JSON.stringify(seeds, null, 2));

    // Create a new results object
    const result = new Result();
    const seed = seeds.entities[0];
    const id = seed.connectorKeys[0].id;

    const url = `${config.queryUrlRoot}/id=${id}/Committees`;

    const response = await axios.get(url, this.axiosConfig);
    const data = response.data;
    console.log(JSON.stringify(data, null, 2));

    const personEntity = result.addEntityFromSeed(seed);
    this.addLinkedCommitteeToResult(result, personEntity, response);
  
    return result;
  }
  
  @service({ name: "Find Committees for Multiple (Synchronous)" })
  async findCommitteesForMultipleSync(
    @seeds(
      {
        types: [schema.Person],
        min: 1,
        max: 100,
      }
    ) seeds: Seeds
  ) {

    const result = new Result();

    for(const seed of seeds.entities) {
      const personEntity = result.addEntityFromSeed(seed);
      for (const connectorKey of seed.connectorKeysByType(schema.Person)) {
        const id = connectorKey.id;
        const url = `${config.queryUrlRoot}/id=${id}/Committees`;
        const response = await axios.get(url, this.axiosConfig);
        this.addLinkedCommitteeToResult(result, personEntity, response);
      }
    }

    return result;

  }

  @service({ name: "Find Committees for Multiple (Asynchronous)" })
  async findCommitteesForMultipleAsync(
    @seeds(
      {
        types: [schema.Person],
        min: 1,
        max: 100,
      }
    ) seeds: Seeds
  ) {

    const result = new Result();
    // Make a request for each seed/key and gather up all the promises into an array
    const promises = [];
    
    for (const seed of seeds.entities) {
      const personEntity = result.addEntityFromSeed(seed);
      for (const connectorKey of seed.connectorKeysByType(schema.Person)) {
        const id = connectorKey.id;
        const url = `${config.queryUrlRoot}/id=${id}/Committees`;
        // note the lack of asyc before the axios.get call
        // push the promise onto the array
        promises.push(axios.get(url, this.axiosConfig)
          .then( (response: any) => {
            this.addLinkedCommitteeToResult(result, personEntity, response);
          }).catch((error: any) => {
          result.status = "Warning";
          result.statusMessage = "At least some items were not available";
          console.log("Caught error: " + error);
        }));
      }
    }

    // Wait for all the promises in the array to complete
    await Promise.all(promises);

    return result;

  }

}
  
  
  
  