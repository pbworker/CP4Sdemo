import { aliasProxyHandler, Aliases, BaseSchema, EntityType, LinkType } from 'connector-sdk';


// Entity Interfaces:
interface Person extends EntityType {
  FullName: string,
  DateOfBirth: string,
  FirstName: string,
  Surname: string
}

interface Committee extends EntityType {
  Name: string;
}

// Link Interfaces:
interface MemberOf extends LinkType {
  overrides?: MemberOf[];
  From: string;
  To: string;
}


// Pull entity and link type interfaces together into the Schema interface
interface Schema extends BaseSchema {
  // Aliases
  Person: Person;
  Committee: Committee;
  MemberOf: MemberOf;
}

// Export a Proxy for the Schema
export const schema: Schema = new Proxy(<Schema>{}, aliasProxyHandler);

// Different instance - in this case, will be mapped for the Framework.
const framework: Schema = {
  DefaultEntity: {
    typeId: "i2.genericEntity"
  },
  DefaultLink: {
    typeId: "i2.genericLink"
  },

  Person: {
    typeId: "Person",
    FullName: "Full Name",
    DateOfBirth: "Date of Birth",
    FirstName: "First Name",
    Surname: "Surname"

  },
 
  Committee: {
    typeId: "Committee",
    Name: "Name"
  },

  MemberOf: {
    typeId: "Member of",
    From: "From",
    To: "To"
  }
}


const lawEnforcement: Schema = {
  DefaultEntity: {
    typeId: "ET5"
  },
  DefaultLink: {
    typeId: "LME1"
  },

  Person: {
    typeId: "ET5",
    FullName: "PER97",
    DateOfBirth: "PER9",
    FirstName: "PER4",
    Surname: "PER6"

  },
 
  Committee: {
    typeId: "ET4",
    Name: "ORG2"
  },

  MemberOf: {
    typeId: "LME1",
    From: "LME5",
    To: "LME6"
  }
}

export const aliases: any = { framework, lawEnforcement };


