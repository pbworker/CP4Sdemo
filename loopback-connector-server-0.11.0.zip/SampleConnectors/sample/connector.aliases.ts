import { EntityType, LinkType, BaseSchema, aliasProxyHandler} from 'connector-sdk';


// Entity Interfaces:
interface IPAddress extends EntityType {
  Address: string,
}

interface Malware extends EntityType {
  Family: string;
  MD5Hash: string;
  SHA1Hash: string;
}

// Link Interfaces:
interface AssociatedWith extends LinkType {
  overrides?: AssociatedWith[];
}

// Pull entity and link type interfaces together into the Schema interface
interface Schema extends BaseSchema {
  // Aliases
  IPAddress: IPAddress;
  Malware: Malware;
  AssociatedWith: AssociatedWith;
}

// Export a Proxy for the Schema
export const schema: Schema = new Proxy(<Schema>{}, aliasProxyHandler);

// First Schema instance.
const cyber: Schema = {
  DefaultEntity: {
    typeId: "ET2"
  },
  DefaultLink: {
    typeId: "LT40"
  },
  IPAddress: {
    typeId: "ET10",
    Address: "PT115"
  },
  Malware: {
    typeId: "ET9",
    Family: "PT46",
    SHA1Hash: "PT47",
    MD5Hash: "PT48"
  },
  AssociatedWith: {
    typeId: "LT40"
  }
}

// Different instance of the schema to map to another schema
const lawEnforcement: Schema = {
  DefaultEntity: {
    typeId: "ET5"
  },
  DefaultLink: {
    typeId: "LAS1"
  },
  IPAddress: {
    typeId: "ET5",
    Address: "PER97"
  },
  Malware: {
    typeId: "ET4",
    Family: "",
    SHA1Hash: "",
    MD5Hash: ""
  },

  AssociatedWith: {
    typeId: "LAS1",
    overrides: [
      {
        fromType: schema.IPAddress,
        toType: schema.Malware,
        typeId: "LME1"
      }
    ]
  },
}


// Different instance - in this case, will be mapped for the Framework.
const frameworkDefault: Schema = {
  DefaultEntity: {
    typeId: "i2.genericEntity"
  },
  DefaultLink: {
    typeId: "i2.genericLink"
  },
  IPAddress: {
    typeId: "IPAddress",
    Address: "Eigenvector"
  },
  Malware: {
    typeId: "Malware",
    Family: "Family",
    SHA1Hash: "SHA1Hash",
    MD5Hash: "MD5Hash"
  },
  AssociatedWith: {
    typeId: "Associated With"
  }
}

export const aliases: any = { cyber, lawEnforcement, frameworkDefault };


