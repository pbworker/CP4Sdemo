import {
  BaseSchema, connector, service, condition, seeds,
  Aliases, AliasedConnector, Result, Seeds, 
  LogicalType, PossibleValue, Status, jwt
} from 'connector-sdk';
import * as config from './connector.conf.json';
import { aliases, schema } from './connector.aliases';
import { inject } from '@loopback/context';


// Create a set of possible values for later use
const samplePossibleValues: PossibleValue[] = [
  { displayName: "Choice 1", value: "1" },
  { displayName: "Choice 2", value: "2" },
  { displayName: "Choice 3", value: "3" }
]

/**
 * Sample Connector
 */
@connector({
  name: "Sample Connector",
  description: "A Sample Connector"
})
export class SampleConnector implements AliasedConnector {
  
  private logger: any;

  constructor(@inject('Logger') logger: any) {
    this.logger = logger;
  }

  // Boiler-plate as implements AliasedConnector
  getAliases() {
    return new Aliases(aliases);
  }

  // Boiler-plate as implements AliasedConnector
  getSchema(): BaseSchema {
    return schema;
  }

  // Boiler-plate to return connector deployment folder
  getDir() {
    return __dirname;
  }

  /*
   * Basic service that has some conditions and returns some hard coded data
   */
  @service({ name: "Sample Form Controls", description: "A variety of form controls of different types/constraints" })
  async sampleFormControls(
    @condition({
      label: "Validated String",
      description: "String with regex validation",
      logicalType: LogicalType.SINGLE_LINE_STRING,
      validation: {
        regex: 'Password|Passw0rd|LetMeIn',
        message: 'Must be one of Password, Passw0rd or LetMeIn'
      }
    })
    condition1: string,
    @condition({
      label: "Code list",
      description: "Selected From example",
      logicalType: LogicalType.SELECTED_FROM,
      possibleValues: samplePossibleValues
    }) condition2: string,
    @condition({
      label: "Integer",
      description: "Mandatory Integer between 1 & 5",
      logicalType: LogicalType.INTEGER,
      minValue: 1,
      maxValue: 5,
      mandatory: true
    }) condition3: number,
  ) {

    // Just log the various conditions
    this.logger.info("condition1: " + condition1);
    this.logger.info("condition2: " + condition2);
    this.logger.info("condition3: " + condition3);

    // if we need to use an apiKey or whatever, we can configure it connector.conf.json and access it like this:
    this.logger.debug("Got API Key " + config.apiKey);

    // All we need to do is return an empty result set.
    const result = new Result();
    result.status = Status.Warning;
    result.statusMessage = "Empty Results";

    return result;
  }


  /*
   * Basic service that has some conditions and returns some hard coded data
   */
  @service({ name: "Find IPAddress" })
  async findIPAddresses(
    @condition({
      label: "IP Address Octent Number",
      description: "Mandatory Integer between 1 & 999",
      logicalType: LogicalType.INTEGER,
      minValue: 1,
      maxValue: 999,
      mandatory: true
    }) octet: number,
  ) {

    this.logger.info("octet param value is: " + octet);


    // Create a new result object
    const result = new Result();

    // Loop and add an entity to result for each number
    for(let i = 1; i <= octet; i++) {
      const address = `${i}.${i}.${i}.${i}`;
      const entity = result.addEntity(address, schema.IPAddress);
      entity.identity = address;
      entity.setProperty(schema.IPAddress.Address, address);
    }

    // Assuming everything is ok, set status and status message
    result.status = Status.OK;
    result.statusMessage = `Here's ${octet} some hard coded results`;
    return result;
  }


  /*
   * A service that takes some Alias seeds and returns them linked to a hard coded Organisation
   */
  @service({ name: "Find Linked Malware" })
  async findLinkedMalware(
    // This method just takes seeds of type Alias
    @seeds(
      {
        types: [schema.IPAddress],
        min: 1,
        max: 999

      }
    ) seeds: Seeds
  ) {

    this.logger.info("Got seeds " + JSON.stringify(seeds, null, 2));
    // Create a new results object
    const result = new Result();

    // Loop over seed and add the original seed, a Malware (same for all) and a link between them
    seeds.entities.forEach(seed => {
      // Quick way to add original to result
      const originalIPAddress = result.addEntityFromSeed(seed);

      const malwareId = "Malware123";

      // Doesn't matter that this may be created multiple times, it will be deduped by the result
      const malwareEntity = result.addEntity(malwareId, schema.Malware);
      // give it some properties
      malwareEntity.setProperty(schema.Malware.Family, "Corleone");
      malwareEntity.setProperty(schema.Malware.MD5Hash, "MD%CXfghdsfkjghekjrthdfghdfkjghdsfg");
      malwareEntity.setProperty(schema.Malware.SHA1Hash, "dfgretefgdfgdfsgdsfgdfgertshyrtyfgh");

      // create a link between them
      result.addLink(malwareId +  "_" + originalIPAddress.id, schema.AssociatedWith, originalIPAddress, malwareEntity);

      result.status = Status.Warning;

      result.statusMessage = "Hard coded results";

    });

    return result;
  }


  @service({name: "No conditions or seeds but requires JWT", description: "Service require valid JWT."})
  async requireJWT(
    @jwt() jwt: any 
  ) {
    // if it reaches here, the jwt is verified.
    this.logger.info("Received JWT " + JSON.stringify(jwt, null, 2));
    return new Result();
  }
  

}

